      Installing the apigee migrate tool:
       1. Download and install Node.js at http://nodejs.org/download/.
       2. Open a command prompt and install Grunt using the npm command.
           npm install -g grunt-cli
       3. Install the Node.js dependencies that the tool requires.
             npm install
       

Update config.js :
 In config.js of apigee migrate tool, update the url, org, env values as needed.



Sequence for exporting data:
grunt exportTargetServers
grunt exportEnvKVM
grunt exportProducts
grunt exportDevs
grunt exportApps
grunt exportSharedFlows
grunt exportProxies




Configuration to run import :

 Setup GCP project config :
Go to bin folder of gcloud SDK installation inside the code, open terminal and run ‘gcloud init’ to configure the gcp project to run the imports

Export Token as environment variable:
Use this command to export auth token to an environment variable : 
   export TOKEN="$(gcloud auth print-access-token)"


Run import commands to import into ApigeeX Org: 
Run the following import commands to import data from ‘data’ folder of the migrate tool  to ApigeeX  org
grunt importEnvKVM
grunt importTargetServers
grunt importProducts  → to import products
grunt importDevs   → to import Devs
grunt importApps  → to import Apps
grunt importKeys → to import Keys
grunt importSharedFlows
grunt importProxies

grunt deploySharedFlows - deploy to one env
grunt deployProxies - deploy to one env
grunt createEnvKVMMapId


grunt importKeys -v
grunt assignProducts -v
grunt approveProducts -v
grunt revokeProducts -v
grunt revokeKeys -v
grunt createEnvKVMMapId -v
grunt importEnvKVM -v 


Importing developer or app data from a CSV file(Optional):
Fill the data in products.csv, devs.csv, apps.csv and run the following commands from the tool location to read data from CSV files to apigee tool ‘data’ folder:
            
            grunt readCSVProducts -v
            grunt readCSVDevs -v
            grunt readCSVApps -v



