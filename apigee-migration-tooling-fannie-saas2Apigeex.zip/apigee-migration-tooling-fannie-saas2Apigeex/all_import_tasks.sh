#!/bin/bash
grunt importTargetServers -v
grunt importProxies -v
grunt importSharedFlows -v
grunt importDevs -v
grunt importProducts -v
grunt importApps -v
grunt importKeys -v
grunt importProxyKVM -v
grunt importEnvKVM -v
grunt importOrgKVM -v
grunt importFlowHooks -v
grunt importReports -v
