/*jslint node: true */

const path = require('path');
var request = require('request');
var apigee = require('../config.js');
var proxies;
module.exports = function(grunt) {
	'use strict';
	grunt.registerTask('exportProxies', 'Export all proxies from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
		var url = apigee.from.url;
		var org = apigee.from.org;
		var env = apigee.from.env;
		var apis = apigee.from.apis;
		var userid = apigee.from.userid;
		var passwd = apigee.from.passwd;
		var revIndex = apigee.from.revIndex;
		//var oauthToken = process.env.OAUTH; //MODIFIED CODE
		var fs = require('fs');
		var filepath = grunt.config.get("exportProxies.dest.data");
		var done_count =0;
		var done = this.async();
grunt.log.ok("apis to export ====="+apis);
		grunt.verbose.writeln("========================= export Proxies =--==========================" );
		//grunt.verbose.writeln("getting proxies..." + url);
		url = url + "/v1/organizations/" + org + "/apis";

		request(url, function (error, response, body) {
			if (!error && response.statusCode == 200) {
			    proxies =  JSON.parse(body);
			   
			   // for (var i = 0; i < proxies.length; i++) {
			   	for (var i = 0; i < apis.length; i++) {
			    	
			    	//grunt.log.ok("apis  ====="+apis[i]);
			    	//var proxy_url = url + "/" + proxies[i];
			    	var proxy_url = apigee.from.url+ "/v1/organizations/" + org + "/environments/" + env + "/apis/" + apis[i]+ "/deployments";
			    	//grunt.log.ok("proxy_url====="+proxy_url);
			    	//var proxypath=filepath +"/" +env;
var proxypath=filepath ;
			    	grunt.file.mkdir(proxypath);
			    	



			    	//Call proxy details
					request(proxy_url, function (error, response, body) {
						if (!error && response.statusCode == 200) {
							grunt.verbose.writeln(body);
						    var proxy_detail =  JSON.parse(body);
						 //grunt.log.ok("proxy_detail====="+proxy_detail);
                            // var proxy_file = filepath + "/" + proxy_detail.name;
						    // gets max revision - May not be the deployed version
						      var max_rev = proxy_detail.revision[0].name;
						    //var proxy_download_url = url + "/" + proxy_detail.name + "/revisions/" + (max_rev-revIndex) + "?format=bundle";
						    var proxy_download_url = url + "/" + proxy_detail.name + "/revisions/" + max_rev + "?format=bundle";
						    

						    grunt.verbose.writeln ("\nFetching proxy bundle --------  : " + proxy_download_url);
						      //grunt.log.ok("\nFetching proxy bundle --------- : " + proxy_download_url);
						      


						    request(proxy_download_url).auth(userid, passwd, true)
							  .pipe(fs.createWriteStream(proxypath + "/" + proxy_detail.name + '.zip'))
							  .on('close', function () {
							    
							    grunt.verbose.writeln('Proxy ----------- ' + proxy_detail.name + '.zip written!');
							    done_count++;
								if (done_count == apis.length)
								{
									grunt.log.ok('Exported ' + done_count + ' proxies from '+ env);
									 grunt.verbose.writeln('Exported ' + done_count + ' proxies from '+ env);
                                    grunt.verbose.writeln("================== export proxies DONE()" );
									done();
								}
							});
						}
						else
						{
							done_count++;
							if (done_count == apis.length)
							{
								grunt.verbose.writeln('Error exporting ' + done_count + ' proxies.');
								// done();
							} else {
								//grunt.verbose.writeln('Error exporting proxy' + proxy_detail.name);
								 grunt.verbose.writeln('Resp [' + response.statusCode + '] for proxy creation ' + proxy_download_url + ' -----> ' + body);
									//grunt.verbose.writeln('Error exporting proxy' + proxy_detail.name);
							}
							grunt.log.error(error);
						}
					}).auth(userid, passwd, true);
			    	// End proxy details
			    }; 			    
			} 
			else
			{
				grunt.log.error(error);
			}
		}).auth(userid, passwd, true);
		/*
		setTimeout(function() {
		    grunt.verbose.writeln("================== Proxies Timeout done" );
		    done(true);
		}, 5000);
		grunt.verbose.writeln("========================= export Proxies DONE ===========================" );
		*/

	});


	grunt.registerMultiTask('importProxies', 'Import all proxies to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var env = apigee.from.env;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var filepath = grunt.config.get("exportProxies.dest.data");
		var files;
		var done_count = 0;
		var total_count =0;
		var err_count =0;
			var total_count =0;
		url = url + "/v1/organizations/" + org + "/apis?action=import&name=";
		var fs = require('fs');
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
//filepath = filepath+"/"+env;
files.forEach(function(filepath) {
		var filename = filepath.replace(/^.*[\\\/]/, '');
		var name = filename.slice(0, -4);
			//MODIFIED CODE - start
			var gcp_token = process.env.TOKEN; //MODIFIED CODE
			
			var post_url= url+name; 
			var auth_header='Bearer ' + gcp_token;
			const options = {
				url: post_url,
				headers: {
				  'Authorization': auth_header
				}
			  };
			  
			  //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'



			var req = request.post(options, function (err, resp, body) {
				  grunt.log.ok("proxy_create===="+post_url);
				 //var proxy_create =  JSON.parse(body);
			   //grunt.log.ok("proxy_create==after =="+post_url);
			if (err || resp.statusCode!=200) {
			   // grunt.log.error(err);
			   grunt.log.ok('body========= ' + body);
			   grunt.verbose.error('ERROR Resp [' + resp.statusCode + '] for proxy creation ---' + post_url + '--- -> ' + body);
			   //grunt.log.error('ERROR Resp [' + resp.statusCode + '] for proxy creation ' + proxy_create.name + ' -----> ' + body);  
			    err_count++;

			  } else {
			    grunt.verbose.writeln('Resp [' + resp.statusCode + '] for proxy creation ' + post_url + ' -----> ' + body);
			
			  done_count++;
			  }
			  		total_count =done_count+err_count;
			  if (total_count == files.length)
				{
					grunt.log.ok('Imported ' + done_count + ' proxies');
					grunt.log.ok('Error in  ' + err_count + ' proxies');
					//console.log('Processed ' + done_count + ' proxies');
					done();
				}
		
			}.bind( {url: options}) ); //MODIFIED CODE - Removed .auth(userid, passwd, true),use options in post paramters instead of 'url+name'
			var form = req.form();
			form.append('file', fs.createReadStream(filepath));
			
		});
		var done = this.async();


	});

	grunt.registerMultiTask('deleteProxies', 'Delete all proxies from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var err_count =0;
		var total_count =0;
		var done_count =0;
		var files;
		url = url + "/v1/organizations/" + org + "/apis/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
			var auth_header='Bearer ' + gcp_token;
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();
		files.forEach(function(filepath) {
			grunt.verbose.writeln("processing file " + filepath);
			var folders = filepath.split("/");
			var proxy_file = folders[folders.length - 1];
			var proxy = proxy_file.split(".")[0];
			var app_del_url = url + proxy;
			grunt.verbose.writeln(app_del_url);
			const options = {
				url: app_del_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end
			request.del(options,function(error, response, body){
			  grunt.verbose.writeln('Resp [' + response.statusCode + '] for proxy deletion ' + this.app_del_url + ' -> ' + body);
			  if (error || response.statusCode!=200)
			  	{
			  		grunt.verbose.error('ERROR Resp [' + response.statusCode + '] for proxy deletion ' + this.app_del_url + ' -> ' + body); 
			 err_count++;
			 }
			 else
			 	{
			 		done_count++;
			 	}
			 	total_count =done_count+err_count;
			  	if (total_count == files.length)
				{
					grunt.log.ok('Deleted ' + done_count + ' proxies');
					done();
				}
			//}.bind( {app_del_url: app_del_url}) ).auth(userid, passwd, true);	
		}.bind( {app_del_url: app_del_url}) );	
		});
	});


grunt.registerMultiTask('deployProxies', 'Deploy revision 1 on all proxies for org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
			var url = apigee.to.url;
			var org = apigee.to.org;
			var env = apigee.to.env;
			var userid = apigee.to.userid;
			var passwd = apigee.to.passwd;
			//var filepath = grunt.config.get("deployProxies.src.data");
			var done_count =0;
			var err_count =0;
			var total_count =0;
		var files;
		url = url + "/v1/organizations/" + org ;
			//var proxies_url = url +  "/apis" ;
		//url = url + "/v1/organizations/" + org + "/apis/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
			var auth_header='Bearer ' + gcp_token;
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();

			//grunt.log.ok('filepath===out== ' + filepath);
		files.forEach(function(filepath) {
			grunt.verbose.writeln("processing file " + filepath);
			
			grunt.log.ok('filepath===inside== ' + filepath);
			grunt.verbose.writeln("processing file " + filepath);
			var folders = filepath.split("/");
			var proxy_file = folders[folders.length - 1];
			var proxy = proxy_file.split(".")[0];
			
			var proxy_url = url + "/environments/" + env + "/apis/" + proxy + "/revisions/1/deployments"; //MODIFIED CODE -- added proxies. and .name to proxies[i]
				    	grunt.verbose.writeln(proxy_url);
			const options = {
				url: proxy_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end
		request.post(options, function (error, response, body) {

if (!error && response.statusCode == 200) {
								grunt.verbose.writeln('Resp [' + response.statusCode + '] for proxy deployment ' +  proxy_url+ ' -> ' + body);
								//console.log('Resp [' + response.statusCode + '] for proxy deployment ' + this.url + ' -> ' + body);
							done_count++;
							}
							else
							{
								err_count++;
								grunt.log.error('ERROR Resp [' + response.statusCode + '] for proxy deployment ' +  proxy_url + ' -> ' + body);
								//console.log('ERROR Resp [' + response.statusCode + '] for proxy deployment ' + this.url + ' -> ' + body);
							}









			 	total_count =done_count+err_count;
			  	if (total_count == files.length)
				{
					grunt.log.ok('Processed ' + done_count + ' proxies');
					done();
				}
			//}.bind( {app_del_url: app_del_url}) ).auth(userid, passwd, true);	
		}.bind( {proxy_url: proxy_url}) );
		});
	});












//// changed code to deploy proxy from the folder
			

	grunt.registerTask('undeployProxies', 'UnDeploy revision 1 on all proxies for org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
			var url = apigee.to.url;
			var org = apigee.to.org;
			var env = apigee.to.env;
			var userid = apigee.to.userid;
			var passwd = apigee.to.passwd;

			var done_count =0;
			var err_count =0;
			var total_count =0;
			var done = this.async();
			var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
			var auth_header='Bearer ' + gcp_token;
			url = url + "/v1/organizations/" + org ;
			var proxies_url = url +  "/apis" ;
const options1 = {
				url: proxies_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end

			request(options1, function (error, response, body) {
			
				
				if (!error && response.statusCode == 200) {
					//grunt.log.write(body);
				    proxies =  JSON.parse(body);
				  
				    for (var i = 0; i < proxies.proxies.length; i++) {
				    	var proxy_url = url + "/environments/" + env + "/apis/" + proxies.proxies[i].name + "/revisions/1/deployments";
				    	grunt.verbose.writeln(proxy_url);
				    	//Call proxy undeploy
				    	const options = {
				url: proxy_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end
						request.del(options, function (error, response, body) {
							if (!error && response.statusCode == 200) {
								grunt.verbose.writeln(body);
								done_count++;
								grunt.verbose.writeln('Resp [' + response.statusCode + '] for proxy Undeploy ' +  proxy_url+ ' -> ' + body);
								
							}
							else
							{
								//grunt.log.error(error);
								console.log('ERROR Resp [' + response.statusCode + '] for proxy Undeploy ' + proxy_url + ' -> ' + body);
								err_count++;
							}
							total_count =done_count+err_count;
						  	if (total_count == proxies.proxies.length)
							{
								grunt.log.ok('Processed ' + done_count + ' proxies');
								done();
							}
						//}).auth(userid, passwd, true);
				    	// End proxy undeploy
				    });
				    }; 
				    
				} 
				else
				{
					grunt.log.error(error);
				}
			//}).auth(userid, passwd, true);
				});
	});

};

