/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var devs;
//const request = require('request'); // Make sure you have the 'request' library installed

module.exports = function(grunt) {
	'use strict';
	grunt.registerTask('exportDevs', 'Export all developers from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
		var url = apigee.from.url;
		var org = apigee.from.org;
		var userid = apigee.from.userid;
		var passwd = apigee.from.passwd;
		var filepath = grunt.config.get("exportDevs.dest.data");
		var dev_count = 0;
		var done_count = 0;
		var done = this.async();
		grunt.verbose.writeln("========================= export Devs ===========================" );

		grunt.verbose.writeln("getting developers... " + url);
		url = url + "/v1/organizations/" + org + "/developers";

		var dumpDeveloper = function(email) {
			//var dev_url = url + "/" + encodeURIComponent(email);
			var dev_url = url + "/" + email;
			grunt.verbose.writeln("getting developer ---- " + dev_url);

			//Call developer details
			request(dev_url, function (dev_error, dev_response, dev_body) {
				if (!dev_error && dev_response.statusCode == 200) {
					grunt.verbose.writeln(dev_body);
					var dev_detail = JSON.parse(dev_body);
					var dev_file = filepath + "/" + dev_detail.email;
					grunt.file.write(dev_file, dev_body);
					grunt.verbose.writeln('Dev ' + dev_detail.email + ' written!');
				}
				else {
					//if (error)
					if (dev_error)
							{	grunt.verbose.writeln("========================= in dev_error ===========================" );
						grunt.log.error(dev_error);}
					else
						{grunt.log.error(dev_body);
									grunt.verbose.writeln("========================= else dev_error ===========================" );
						}
				}
				done_count++;
					grunt.verbose.writeln("========================= done_count ==========================="+done_count );
						grunt.verbose.writeln("========================= dev_count ===========================" +dev_count);
				//if (done_count == dev_count) {
					if (done_count == 101261) {
					
					grunt.log.ok('Exported ' + done_count + ' developers');
                    grunt.verbose.writeln("================== export Devs DONE()" );
					done();
				}
			}.bind( {dev_url: dev_url}) ).auth(userid, passwd, true);
		}


		var iterateOverDevs = function(start, base_url, callback) {
			var url = base_url;
	grunt.verbose.writeln("============================start==============================" + start);
			if (start) {
				url += "?startKey=" + encodeURIComponent(start);
			}
			grunt.verbose.writeln("getting developers..." + url);

			request(url, function (error, response, body) {
				if (!error && response.statusCode == 200) {
					var devs = JSON.parse(body);
					var last = null;

					// detect none and we're done
					if ( devs.length == 0 ) {
						grunt.log.ok('No developers, done');
						done();
					// detect the only developer returned is the one we asked to start with; that's the end game, but wait.
					} else if ( (devs.length == 1) && (devs[0] == start) ) {
						grunt.log.ok('Retrieved TOTAL of ' + dev_count + ' developers, waiting for callbacks to complete');
					} else {
						dev_count += devs.length;
							grunt.verbose.writeln("=========================devs.length ==========================="+devs.length);
						grunt.verbose.writeln("========================= dev_count ==in else=========================" +dev_count);
						if (start)
							dev_count--;

						for (var i = 0; i < devs.length; i++) {
							// If there was a 'start', don't do it again, because it was processed in the previous callback.
							if (!start || devs[i] != start) {
								callback(devs[i]);
								last = devs[i];
							}
						}

						grunt.log.ok('Retrieved ' + devs.length + ' developers');

						// Keep on calling getDevs() as long as we're getting new developers back
							grunt.log.ok('-------------------last------------------iterate-----------------');
						iterateOverDevs(last, base_url, callback);
					}
				}
				else {
					if (error)
						grunt.log.error(error);
					else
						grunt.log.error(body);
				}

			}).auth(userid, passwd, true);
		}

		// get All developers
			grunt.log.ok('-------------------null------------------iterate-----------------');
		iterateOverDevs(null, url, dumpDeveloper);
		/*
		setTimeout(function() {
		    grunt.verbose.writeln("================== Devs Timeout done" );
		    done(true);
		}, 3000);
		grunt.verbose.writeln("========================= export Devs DONE ===========================" );
		*/
	});



////import--
grunt.registerMultiTask('importDevs', 'Import all developers to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count = 0;
		var import_count = 0; // added to get the number of dev imported
		var err_count = 0; // added to get the number of dev not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		var files;
		url = url + "/v1/organizations/" + org + "/developers";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		files.forEach(function(filepath) {
			//console.log(filepath);
			var content = grunt.file.read(filepath);
			//grunt.verbose.writeln(url);	
			var dev = JSON.parse(content);
			 var email=dev['email'];
			 //var MemberSince =dev['createdAt'].toString();

const epochTime = dev['createdAt']; // example epoch timestamp
const date = new Date(epochTime); // create a new Date object using the epoch timestamp
const MemberSince = date.toLocaleString(); // convert the Date object to a human-readable string
//grunt.log.ok('MemberSince' + MemberSince); 

			 //  to get the Member-Since
dev.attributes.push({
  			"name": "Edge-Member-Since",
  			"value": MemberSince
			});

			///
			delete dev['organizationName'];
	        delete dev['status'];
	        delete dev['createdAt'];
	        delete dev['lastModifiedAt'];
	        delete dev['lastModifiedBy'];
	        delete dev['createdBy'];
	        delete dev['email'];
	        dev['email']= email.toLowerCase();





		//MODIFIED CODE - start
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		
		//var post_url= url; 
		var auth_header='Bearer ' + gcp_token;
		const options = {
			 headers: {
					'Content-Type': 'application/json',
					'Authorization': auth_header
				},
				url:     url,
				body:    JSON.stringify(dev)			
		};
		  
		  //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'
		 
		  request.post(options,
			  function(error, response, body){
			var status = 999;
			if (response)	
			 status = response.statusCode;
			grunt.verbose.writeln('Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body);
			if (error || status!=201)
			{
			  	grunt.verbose.error('ERROR Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body); 
			  	err_count++; // added to get the number of dev not imported
			}
			done_count++;
			if (status==201)// added to get the number of dev imported
			  	import_count++; // added to get the number of dev imported

			if (status==409)// added to get the number of 409 records
			  	conflict_count++; // added to get the number of 409 records
			error_count =err_count-conflict_count; // added to get the error record count
			if (done_count == files.length)
			{
				grunt.log.ok('Processed ' + done_count + ' developer record(s)'); // code changed here
				grunt.log.ok('Imported ' + import_count + ' developer(s)'); // added to get the number of dev imported
				grunt.log.ok('Conflict in ' + 	conflict_count + ' developer record(s)'); // added to get the number of 409 records
				grunt.log.ok('Error in ' + 	error_count + ' developer record(s)'); // added to get the error record count
				done();
			}

			}.bind( {url: url}) ); //modified - removed .auth(userid, passwd, true);
		});
	});
////import--
	

	grunt.registerMultiTask('deleteDevs', 'Delete all developers from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count = 0;
		var error_count = 0;
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		var auth_header='Bearer ' + gcp_token;
		var files = this.filesSrc;
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		files.forEach(function(filepath) {
			var content = grunt.file.read(filepath);
			var dev = JSON.parse(content);
			var del_url = url + encodeURIComponent(dev.email).toLowerCase();
			//var del_url = url + dev.email.toLowerCase();
			grunt.verbose.writeln(del_url);	


			const dele_options = {
				headers: {
					   
					   'Authorization': auth_header
				   },
				   url: del_url,
				
 };
			request.del(dele_options, function(error, response, body){
			  var status = 999;
			  if (response)	
				status = response.statusCode;
			  grunt.verbose.writeln('Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body);
			  if (error || status!=200)
			  { 
			  	grunt.verbose.error('ERROR Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body); 
			  	error_count++;
			  }
			  done_count++;
			  if (done_count == files.length)
			  {
				grunt.log.ok('Deleted ' + (done_count-error_count) + ' developers');
				done();
			  }
			}.bind( {del_url: del_url}) );

		});
	});
};
