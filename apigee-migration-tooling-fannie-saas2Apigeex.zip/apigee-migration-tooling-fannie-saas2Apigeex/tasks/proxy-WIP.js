/*jslint node: true */

const path = require('path');
var request = require('request');
var apigee = require('../config.js');
var proxies;
var async = require('async');
module.exports = function(grunt) {
	'use strict';
grunt.registerTask('exportProxies', 'Export all proxies from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
    var url = apigee.from.url;
    var org = apigee.from.org;
    var env = apigee.from.env;
    var apis = apigee.from.apis;
    var userid = apigee.from.userid;
    var passwd = apigee.from.passwd;
    var fs = require('fs');
    var filepath = grunt.config.get("exportProxies.dest.data");
    var proxyCount = 0;
    var done = this.async();

    grunt.file.mkdir(filepath + "/proxies");

    grunt.verbose.writeln("========================= export Proxies ===========================");
    url = url + "/v1/organizations/" + org + "/apis";

    request(url, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            var proxies = JSON.parse(body);

            async.eachSeries(apis, function (api, callback) {
                var proxy_url = apigee.from.url + "/v1/organizations/" + org + "/environments/" + env + "/apis/" + api + "/deployments";
                var proxypath1 = filepath + "/proxyrun1" + "/";
                 var proxypath2 = filepath + "/proxyrun2" + "/";
                  var proxypath3 = filepath + "/proxyrun3"+ "/";
                   var proxypath4 = filepath + "/proxyrun4"  + "/";
                    var proxypath5 = filepath + "/proxyrun5" + "/";
                grunt.file.mkdir(proxypath1);
                  grunt.file.mkdir(proxypath2);
                    grunt.file.mkdir(proxypath3);
                      grunt.file.mkdir(proxypath4);
                        grunt.file.mkdir(proxypath5);

                request(proxy_url, function (error, response, body) {
                    if (!error && response.statusCode == 200) {
                        var proxy_detail = JSON.parse(body);
                        var deployedRevision = proxy_detail.revision[0].name;
                        var revisions = [];
                        for (var i = deployedRevision - 4; i <= deployedRevision; i++) {
                            revisions.push({ name: i });
                        }
                        var revisionCount = 0;
                        var counter = 1;

                        async.eachSeries(revisions, function (revision, revCallback) {
                            var proxy_download_url = url + "/" + proxy_detail.name + "/revisions/" + revision.name + "?format=bundle";
                            var proxyFileName = proxy_detail.name + revision.name + ".zip";
var proxypath1 = filepath + "/proxyrun" + counter + "/";
grunt.verbose.writeln("========================= proxyFileName==========================="+proxyFileName);
var path=filepath + "/proxyrun"+counter+ "/";
grunt.verbose.writeln("========================= path==========================="+path);

                            request(proxy_download_url).auth(userid, passwd, true)
                                .pipe(fs.createWriteStream(path+ proxyFileName))
                                .on('close', function () {
                                    grunt.verbose.writeln('Proxy ' + proxyFileName + ' written!');
                                    revisionCount++;
                                    counter++;
                                    revCallback();
                                })
                                .on('error', function (err) {
                                    grunt.log.error('Error exporting ' + proxyFileName);
                                    revisionCount++;
                                    counter++;
                                    revCallback(err);
                                });
                        }, function (err) {
                            if (err) {
                                grunt.verbose.writeln('Error exporting revisions for ' + proxy_detail.name);
                            } else {
                                grunt.log.ok('Exported ' + revisionCount + ' revisions for ' + proxy_detail.name);
                            }

                            callback();
                        });
                    } else {
                        grunt.log.error('Error exporting ' + proxy_detail.name);
                        callback();
                    }
                }).auth(userid, passwd, true);

                proxyCount++;
            }, function () {
                grunt.log.ok('Exported ' + proxyCount + ' proxies from ' + env);
                grunt.verbose.writeln("================== export proxies DONE() ==========================");
                done();
            });
        } else {
            grunt.log.error(error);
        }
    }).auth(userid, passwd, true);
});






	grunt.registerMultiTask('importProxies', 'Import all proxies to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var env = apigee.from.env;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var filepath = grunt.config.get("exportProxies.dest.data");
		var files;
		var done_count = 0;
		var total_count =0;
		var err_count =0;
			var total_count =0;
		url = url + "/v1/organizations/" + org + "/apis?action=import&name=";
		var fs = require('fs');
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
//filepath = filepath+"/"+env;
files.forEach(function(filepath) {
		var filename = filepath.replace(/^.*[\\\/]/, '');
		var name = filename.slice(0, -4);
			//MODIFIED CODE - start
			var gcp_token = process.env.TOKEN; //MODIFIED CODE
			
			var post_url= url+name; 
			var auth_header='Bearer ' + gcp_token;
			const options = {
				url: post_url,
				headers: {
				  'Authorization': auth_header
				}
			  };
			  
			  //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'



			var req = request.post(options, function (err, resp, body) {
				 var proxy_create =  JSON.parse(body);
			   //grunt.log.ok("proxy_create===="+post_url);
			if (err || resp.statusCode!=200) {
			   // grunt.log.error(err);
			   
			   grunt.verbose.error('ERROR Resp [' + resp.statusCode + '] for proxy creation ---' + post_url + '--- -> ' + body);
			   //grunt.log.error('ERROR Resp [' + resp.statusCode + '] for proxy creation ' + proxy_create.name + ' -----> ' + body);  
			    err_count++;

			  } else {
			    grunt.verbose.writeln('Resp [' + resp.statusCode + '] for proxy creation ' + proxy_create.name + ' -----> ' + body);
			
			  done_count++;
			  }
			  		total_count =done_count+err_count;
			  if (total_count == files.length)
				{
					grunt.log.ok('Imported ' + done_count + ' proxies');
					grunt.log.ok('Error in  ' + err_count + ' proxies');
					//console.log('Processed ' + done_count + ' proxies');
					done();
				}
		
			}.bind( {url: options}) ); //MODIFIED CODE - Removed .auth(userid, passwd, true),use options in post paramters instead of 'url+name'
			var form = req.form();
			form.append('file', fs.createReadStream(filepath));
			
		});
		var done = this.async();


	});

	grunt.registerMultiTask('deleteProxies', 'Delete all proxies from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var err_count =0;
		var total_count =0;
		var done_count =0;
		var files;
		url = url + "/v1/organizations/" + org + "/apis/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
			var auth_header='Bearer ' + gcp_token;
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();
		files.forEach(function(filepath) {
			grunt.verbose.writeln("processing file " + filepath);
			var folders = filepath.split("/");
			var proxy_file = folders[folders.length - 1];
			var proxy = proxy_file.split(".")[0];
			var app_del_url = url + proxy;
			grunt.verbose.writeln(app_del_url);
			const options = {
				url: app_del_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end
			request.del(options,function(error, response, body){
			  grunt.verbose.writeln('Resp [' + response.statusCode + '] for proxy deletion ' + this.app_del_url + ' -> ' + body);
			  if (error || response.statusCode!=200)
			  	{
			  		grunt.verbose.error('ERROR Resp [' + response.statusCode + '] for proxy deletion ' + this.app_del_url + ' -> ' + body); 
			 err_count++;
			 }
			 else
			 	{
			 		done_count++;
			 	}
			 	total_count =done_count+err_count;
			  	if (total_count == files.length)
				{
					grunt.log.ok('Deleted ' + done_count + ' proxies');
					done();
				}
			//}.bind( {app_del_url: app_del_url}) ).auth(userid, passwd, true);	
		}.bind( {app_del_url: app_del_url}) );	
		});
	});


	grunt.registerTask('deployProxies', 'Deploy revision 1 on all proxies for org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
			var url = apigee.to.url;
			var org = apigee.to.org;
			var env = apigee.to.env;
			var userid = apigee.to.userid;
			var passwd = apigee.to.passwd;
			var done_count =0;
			var err_count =0;
			var total_count =0;
			var done = this.async();
			url = url + "/v1/organizations/" + org ;
			var proxies_url = url +  "/apis" ;
			var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
			var auth_header='Bearer ' + gcp_token;
			const options1 = {
				url: proxies_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end

			//request(proxies_url, function (error, response, body) {//MODIFIED CODE 
			request(options1, function (error, response, body) {
				if (!error && response.statusCode == 200) {
					//grunt.log.write(body);
				    proxies =  JSON.parse(body);
				
				    for (var i = 0; i < proxies.proxies.length; i++) {//MODIFIED CODE  added proxies.
				    	var proxy_url = url + "/environments/" + env + "/apis/" + proxies.proxies[i].name + "/revisions/1/deployments"; //MODIFIED CODE -- added proxies. and .name to proxies[i]
				    	grunt.verbose.writeln(proxy_url);
				    	//Call proxy deploy
				    	//MODIFIED CODE - start
	
			const options = {
				url: proxy_url,
				headers: {
				  'Authorization': auth_header
				}
			  };
			  
			  //MODIFIED CODE - end 
						//request.post(proxy_url, function (error, response, body) {//MODIFIED CODE
						request.post(options, function (error, response, body) {
							if (!error && response.statusCode == 200) {
								grunt.verbose.writeln('Resp [' + response.statusCode + '] for proxy deployment ' + this.url + ' -> ' + body);
								//console.log('Resp [' + response.statusCode + '] for proxy deployment ' + this.url + ' -> ' + body);
							done_count++;
							}
							else
							{
								err_count++;
								grunt.log.error('ERROR Resp [' + response.statusCode + '] for proxy deployment ' + this.url + ' -> ' + body);
								//console.log('ERROR Resp [' + response.statusCode + '] for proxy deployment ' + this.url + ' -> ' + body);
							}
							total_count =done_count+err_count;
						  	if (total_count == proxies.proxies.length)
							{
								grunt.log.ok('Processed ' + done_count + ' proxies');
								//console.log('Processed ' + done_count + ' proxies');
								done();
							}
						});//MODIFIED CODE--- removed-----.auth(userid, passwd, true);
				    	// End proxy deploy
				    }; 
				    
				} 
				else
				{
					grunt.log.error(error);
					console.log(error);
				}
			}.bind( {proxies_url: proxies_url}) ); //MODIFIED CODE--- removed-----.auth(userid, passwd, true) 
	});

	grunt.registerTask('undeployProxies', 'UnDeploy revision 1 on all proxies for org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
			var url = apigee.to.url;
			var org = apigee.to.org;
			var env = apigee.to.env;
			var userid = apigee.to.userid;
			var passwd = apigee.to.passwd;

			var done_count =0;
			var err_count =0;
			var total_count =0;
			var done = this.async();
			var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
			var auth_header='Bearer ' + gcp_token;
			url = url + "/v1/organizations/" + org ;
			var proxies_url = url +  "/apis" ;
const options1 = {
				url: proxies_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end

			request(options1, function (error, response, body) {
			
				
				if (!error && response.statusCode == 200) {
					//grunt.log.write(body);
				    proxies =  JSON.parse(body);
				  
				    for (var i = 0; i < proxies.proxies.length; i++) {
				    	var proxy_url = url + "/environments/" + env + "/apis/" + proxies.proxies[i].name + "/revisions/1/deployments";
				    	grunt.verbose.writeln(proxy_url);
				    	//Call proxy undeploy
				    	const options = {
				url: proxy_url,
				headers: {
				  'Authorization': auth_header
				}
			  };//MODIFIED CODE -end
						request.del(options, function (error, response, body) {
							if (!error && response.statusCode == 200) {
								grunt.verbose.writeln(body);
								done_count++;
							}
							else
							{
								//grunt.log.error(error);
								console.log('ERROR Resp [' + response.statusCode + '] for proxy Undeploy ' + this.proxy_url + ' -> ' + body);
								err_count++;
							}
							total_count =done_count+err_count;
						  	if (total_count == proxies.proxies.length)
							{
								grunt.log.ok('Processed ' + done_count + ' proxies');
								done();
							}
						//}).auth(userid, passwd, true);
				    	// End proxy undeploy
				    });
				    }; 
				    
				} 
				else
				{
					grunt.log.error(error);
				}
			//}).auth(userid, passwd, true);
				});
	});

};

