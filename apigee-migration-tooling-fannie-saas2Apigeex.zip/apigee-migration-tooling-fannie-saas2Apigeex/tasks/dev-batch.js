/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var devs;
//const request = require('request'); // Make sure you have the 'request' library installed


var grunt = require('grunt');


module.exports = function (grunt) {
    'use strict';

    grunt.registerTask('exportDevs', 'Export all developers from org ' + apigee.from.org + " [" + apigee.from.version + "]", function () {
        var url = apigee.from.url;
        var org = apigee.from.org;
        var userid = apigee.from.userid;
        var passwd = apigee.from.passwd;
        var filepath = grunt.config.get("exportDevs.dest.data");
        var batchSize = 5000; // Adjust batch size as needed
        var currentPage = 1;
        var totalPages = Math.ceil(apigee.totalRecords / batchSize); // Calculate total pages

        grunt.verbose.writeln("========================= export Devs ===========================");

        grunt.verbose.writeln("getting developers... " + url);
        url = url + "/v1/organizations/" + org + "/developers";

        var dumpDevelopersBatch = function (pageNumber) {
            var offset = (pageNumber - 1) * batchSize;
            var batchUrl = url + "?startKey=" + offset + "&count=" + batchSize;

            grunt.verbose.writeln("Getting developers batch " + pageNumber);

            request(batchUrl, function (error, response, body) {
                if (error || response.statusCode !== 200) {
                    grunt.log.error('Error retrieving developer batch ' + pageNumber);
                    done();
                } else {
                    var devs = JSON.parse(body);
                    grunt.log.ok('Retrieved ' + devs.length + ' developers in batch ' + pageNumber);

                    async.eachSeries(devs, function (developer, callback) {
                        var dev_file = filepath + "/" + developer.email;
                        grunt.file.write(dev_file, JSON.stringify(developer));
                        grunt.verbose.writeln('Dev ' + developer.email + ' written!');
                        callback();
                    }, function (err) {
                        if (err) {
                            grunt.log.error('Error writing developer data');
                        }
                        currentPage++;

                        if (currentPage <= totalPages) {
                            setTimeout(function () {
                                dumpDevelopersBatch(currentPage);
                            }, 5000); // 5 seconds delay between batches
                        } else {
                            grunt.log.ok('Exported ' + apigee.totalRecords + ' developers');
                            grunt.verbose.writeln("================== export Devs DONE()");
                            done();
                        }
                    });
                }
            }).auth(userid, passwd, true);
        };

        // Start retrieving developers in batches
        dumpDevelopersBatch(currentPage);
    });





////import--
grunt.registerMultiTask('importDevs', 'Import all developers to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count = 0;
		var import_count = 0; // added to get the number of dev imported
		var err_count = 0; // added to get the number of dev not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		var files;
		url = url + "/v1/organizations/" + org + "/developers";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		files.forEach(function(filepath) {
			//console.log(filepath);
			var content = grunt.file.read(filepath);
			//grunt.verbose.writeln(url);	
			var dev = JSON.parse(content);
			 var email=dev['email'];
			 //var MemberSince =dev['createdAt'].toString();

const epochTime = dev['createdAt']; // example epoch timestamp
const date = new Date(epochTime); // create a new Date object using the epoch timestamp
const MemberSince = date.toLocaleString(); // convert the Date object to a human-readable string
//grunt.log.ok('MemberSince' + MemberSince); 

			 //  to get the Member-Since
dev.attributes.push({
  			"name": "Edge-Member-Since",
  			"value": MemberSince
			});

			///
			delete dev['organizationName'];
	        delete dev['status'];
	        delete dev['createdAt'];
	        delete dev['lastModifiedAt'];
	        delete dev['lastModifiedBy'];
	        delete dev['createdBy'];
	        delete dev['email'];
	        dev['email']= email.toLowerCase();





		//MODIFIED CODE - start
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		
		//var post_url= url; 
		var auth_header='Bearer ' + gcp_token;
		const options = {
			 headers: {
					'Content-Type': 'application/json',
					'Authorization': auth_header
				},
				url:     url,
				body:    JSON.stringify(dev)			
		};
		  
		  //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'
		 
		  request.post(options,
			  function(error, response, body){
			var status = 999;
			if (response)	
			 status = response.statusCode;
			grunt.verbose.writeln('Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body);
			if (error || status!=201)
			{
			  	grunt.verbose.error('ERROR Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body); 
			  	err_count++; // added to get the number of dev not imported
			}
			done_count++;
			if (status==201)// added to get the number of dev imported
			  	import_count++; // added to get the number of dev imported

			if (status==409)// added to get the number of 409 records
			  	conflict_count++; // added to get the number of 409 records
			error_count =err_count-conflict_count; // added to get the error record count
			if (done_count == files.length)
			{
				grunt.log.ok('Processed ' + done_count + ' developer record(s)'); // code changed here
				grunt.log.ok('Imported ' + import_count + ' developer(s)'); // added to get the number of dev imported
				grunt.log.ok('Conflict in ' + 	conflict_count + ' developer record(s)'); // added to get the number of 409 records
				grunt.log.ok('Error in ' + 	error_count + ' developer record(s)'); // added to get the error record count
				done();
			}

			}.bind( {url: url}) ); //modified - removed .auth(userid, passwd, true);
		});
	});
////import--
	

	grunt.registerMultiTask('deleteDevs', 'Delete all developers from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count = 0;
		var error_count = 0;
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		var auth_header='Bearer ' + gcp_token;
		var files = this.filesSrc;
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		files.forEach(function(filepath) {
			var content = grunt.file.read(filepath);
			var dev = JSON.parse(content);
			var del_url = url + dev.email;
			grunt.verbose.writeln(del_url);	


			const dele_options = {
				headers: {
					   
					   'Authorization': auth_header
				   },
				   url: del_url,
				
 };
			request.del(dele_options, function(error, response, body){
			  var status = 999;
			  if (response)	
				status = response.statusCode;
			  grunt.verbose.writeln('Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body);
			  if (error || status!=200)
			  { 
			  	grunt.verbose.error('ERROR Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body); 
			  	error_count++;
			  }
			  done_count++;
			  if (done_count == files.length)
			  {
				grunt.log.ok('Deleted ' + (done_count-error_count) + ' developers');
				done();
			  }
			}.bind( {del_url: del_url}) );

		});
	});
};
