/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');

var fs = require("fs");


var products;
module.exports = function(grunt) {
	'use strict';
	grunt.registerTask('exportProducts', 'Export all products from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
		var url = apigee.from.url;
		var org = apigee.from.org;
		var userid = apigee.from.userid;
		var passwd = apigee.from.passwd;
		var filepath = grunt.config.get("exportProducts.dest.data");
		var done_count =0;
		var done = this.async();
		grunt.verbose.writeln("========================= export Products ===========================" );

		grunt.verbose.writeln("getting products..." + url);
		url = url + "/v1/organizations/" + org + "/apiproducts";

		request(url, function (error, response, body) {
			if (!error && response.statusCode == 200) {
				grunt.log.write("PRODUCTS: " + body);
			    products =  JSON.parse(body);
			    
			    if( products.length == 0 ) {
			    	grunt.verbose.writeln("No Products");
			    	done();
			    }
			    for (var i = 0; i < products.length; i++) {
			    	var product_url = url + "/" + products[i];
			    	grunt.file.mkdir(filepath);

			    	//Call product details
			    	grunt.verbose.writeln("PRODUCT URL: " + product_url.length + " " + product_url);
			    	// An Edge bug allows products to be created with very long names which cannot be used in URLs.
			    	if( product_url.length > 1024 ) {
			    		grunt.log.write("SKIPPING Product, URL too long: ");
			    		done_count++;
			    	} else {
						request(product_url, function (error, response, body) {
							if (!error && response.statusCode == 200) {
								grunt.verbose.writeln("PRODUCT " + body);
							    var product_detail =  JSON.parse(body);
							    var dev_file = filepath + "/" + product_detail.name;
							    grunt.file.write(dev_file, body);

							    grunt.verbose.writeln('Exported Product ' + product_detail.name);
							}
							else
							{
								grunt.verbose.writeln('Error Exporting Product ' + product_detail.name);
								grunt.log.error(error);
							}

							done_count++;
							if (done_count == products.length)
							{
								grunt.log.ok('Processed ' + done_count + ' products');
	                            grunt.verbose.writeln("================== export products DONE()" );
								done();
							}
						}).auth(userid, passwd, true);
					}
			    	// End product details
			    };
			    
			} 
			else
			{
				grunt.log.error(error);
			}
		}).auth(userid, passwd, true);
		/*
		setTimeout(function() {
		    grunt.verbose.writeln("================== Products Timeout done" );
		    done(true);
		}, 10000);
		grunt.verbose.writeln("========================= export Products DONE ===========================" );
		*/
	});
			

	

	grunt.registerMultiTask('importProducts', 'Import all products to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var gcp_token = process.env.TOKEN; //modified code
		var auth_header='Bearer ' + gcp_token; //modified code
		var files = this.filesSrc; //'data/products/helloworld'
		
		var done_count=0;
		var import_count = 0; // added to get the number of products imported
		var err_count = 0; // added to get the number of products not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		url = url + "/v1/organizations/" + org + "/apiproducts";
		var done = this.async();
 
		files.forEach(function(filepath) {
			var content = grunt.file.read(filepath);
			var content_json=JSON.parse(content); //modified code
			delete content_json['createdBy']; //modified code
			delete content_json['createdAt']; //modified code
			delete content_json['lastModifiedBy']; //modified code -- for saas to apigeeX change
			delete content_json['lastModifiedAt']; //modified code -- for saas to apigeeX change
/*
var newJson = {
  "operationGroup": {
    "operationConfigs": [
      {
        "apiSource": content_json.proxies[0],
        "operations": [
          {
            "resource": content_json.apiResources[0]
          }
        ],
        "quota": {}
      }
    ],
    "operationConfigType": "proxy"
  }
};
content_json = Object.assign(content_json, newJson);

*/

// parse old JSON string into an object
/*
const oldJsonObj = JSON.parse(content);

// create empty object for new JSON
const newJsonObj = {};

// copy properties from old JSON object to new JSON object
newJsonObj.approvalType = oldJsonObj.approvalType;
newJsonObj.attributes = oldJsonObj.attributes;
newJsonObj.description = oldJsonObj.description;
newJsonObj.displayName = oldJsonObj.displayName;
//newJsonObj.environments = oldJsonObj.environments;
newJsonObj.name = oldJsonObj.name.trim();
newJsonObj.scopes = oldJsonObj.scopes;
newJsonObj.quota = oldJsonObj.quota;
newJsonObj.quotaInterval = oldJsonObj.quotaInterval;
newJsonObj.quotaTimeUnit = oldJsonObj.quotaTimeUnit;



const oldEnvironments = oldJsonObj.environments;
const newEnvironments = [];
for (let i = 0; i < oldEnvironments.length; i++) {
  const env = oldEnvironments[i];
  if (env === "PDE") {
    newEnvironments.push("pde");
  } else if (env === "TEST01") {
    newEnvironments.push("tst01-01");
  }  else if (env === "TEST02") {
    newEnvironments.push("tst02-01");
  } else if (env === "TEST04") {
    newEnvironments.push("tst04-01");
  } else if (env === "TEST05") {
    newEnvironments.push("tst05-01");
  } else if (env === "TEST06") {
    newEnvironments.push("tst06-01");
  }else if (env === "UAT01") {
    newEnvironments.push("uat");
  } else  {
    newEnvironments.push(env);
  } 
}
newJsonObj.environments = newEnvironments;

if (!oldJsonObj.apiResources || oldJsonObj.apiResources.length === 0) {
  newJsonObj.apiResources = ["/"];
}
else
{
	newJsonObj.apiResources = oldJsonObj.apiResources;
}

// create operationGroup object in new JSON object
const operationGroup = {
  operationConfigs: [],
  operationConfigType: "proxy"
};

// loop through proxies in old JSON object and create new objects for operationConfigs array
/*
oldJsonObj.proxies.forEach(proxy => {
  const operationConfig = {
    apiSource: proxy,
    operations: [
      {
        resource: "/"
      }
    ]
  };
  operationGroup.operationConfigs.push(operationConfig);
});
*/
/*
// Loop through each proxy and apiResource in the old JSON
oldJsonObj.proxies.forEach((proxy) => {
  newJsonObj.apiResources.forEach((resource) => {
    // Add a new operation configuration to the new JSON
    operationGroup.operationConfigs.push({
      apiSource: proxy,
      operations: [
        {
          resource: resource
        }
      ]
    });
  });
});




// add operationGroup object to new JSON object
newJsonObj.operationGroup = operationGroup;



// convert new JSON object to string
//const newJsonString = JSON.stringify(newJsonObj);
delete newJsonObj['apiResources']; 
var content_str = JSON.stringify(newJsonObj); //modified code
delete content_json['proxies']; //modified code -- for saas to apigeeX change
			delete content_json['apiResources']; //modified code -- for saas to apigeeX change
*/
			var content_str = JSON.stringify(content_json); //modified code
				grunt.log.ok("Product------------------"+content_str); 
			
			//grunt.verbose.writeln(content);	
			const options = {
				headers: {'content-type' : 'application/json','Authorization':auth_header}, //modified code
				url:     url,
			    body:    content_str  //modified code
			  };
			//grunt.log.writeln("options " + JSON.stringify(options)); //modified and added options in next line

			request.post(options, function(error, response, body){ //modified code
			  var status = 999;
			  if (response)	{
				//console.log(response);
				status = response.statusCode;
			  }
			  grunt.log.writeln('Resp [' + status + '] for product creation -- '+JSON.parse(content_str).name+'--- ' + this.url + ' -> ' +body);
			  if (error || status!=201)
			  { 
				//console.log("error status is" + status ); //modified
			  	grunt.verbose.error('ERROR Resp [' + status + '] for product creation -- '+JSON.parse(content_str).name+'--- ' +  this.url + ' -> ' +body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for product creation  --'+JSON.parse(content_str).name+'--- ' +  this.url + ' -> ' +body); 
			  	err_count++; // added to get the number of products not imported

			  }
			  if (status==201)// added to get the number of products imported
			 	import_count++; // added to get the number of products imported
			

			  if (status==409)// added to get the number of 409 records
			  conflict_count++; // added to get the number of 409 records
			  

			error_count =err_count-conflict_count; // added to get the error record count
			 done_count++;
			if (done_count == files.length)
			{
				grunt.log.ok('Processed ' + done_count + ' product record(s)');
				grunt.log.ok('Imported ' + import_count + ' product(s) ');  // added to get the number of products imported
				grunt.log.ok('Conflict in ' + 	conflict_count + ' product record(s) ') ; // added to get the number of 409 records
				grunt.log.ok('Error in ' + 	error_count + ' product record(s) ' );  // added to get the error record count
				done();
			}
			}.bind( {url: url}) );//MODIFIED CODE - Removed.auth(userid, passwd, true);

		});
	});

	grunt.registerMultiTask('deleteProducts', 'Delete all products from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var files = this.filesSrc;
		var done_count = 0;
		var opts = {flatten: false};
		var f = grunt.option('src');
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		var auth_header='Bearer ' + gcp_token;
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		url = url + "/v1/organizations/" + org + "/apiproducts/";
		var done = this.async();
		files.forEach(function(filepath) {
			var content = grunt.file.read(filepath);
			var product = JSON.parse(content);
			var del_url = url + product.name;
			grunt.verbose.writeln(del_url);	
const options = {
        url: del_url,
        headers: {
          'Authorization': auth_header
        }
        };


			request.del(options, function(error, response, body){
			  var status = 999;
			  if (response)	
				status = response.statusCode;
			  grunt.verbose.writeln('Resp [' + status + '] for product deletion ' + del_url + ' -> ' + body);
			  if (error || status!=200)
			  { 
			  	grunt.verbose.error('ERROR Resp [' + status + '] for product deletion ' + del_url + ' -> ' + body);
			  	grunt.log.ok('ERROR Resp [' + status + '] for product deletion ' + del_url + ' -> ' + body);  
			  }
				done_count++;
				if (done_count == files.length)
				{
					grunt.log.ok('Deleted ' + done_count + ' products');
					done();
				}
			//}.bind( {del_url: del_url}) ).auth(userid, passwd, true);
}.bind( {del_url: del_url}) );
		});
	});

};

