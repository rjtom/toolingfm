/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var apps; 
module.exports = function(grunt) {
	'use strict';
	grunt.registerTask('exportApps', 'Export all apps from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
		var url = apigee.from.url;
		var org = apigee.from.org;
		var userid = apigee.from.userid;
		var passwd = apigee.from.passwd;
		var filepath = grunt.config.get("exportApps.dest.data");
		var done_count =0;
		var dev_count =0;
		var key_count =0;
		var total_apps =0;
		var dev_url;
		var done = this.async();
		grunt.verbose.writeln("========================= export Apps ===========================" );
		grunt.verbose.writeln("getting developers..." + url);
		url = url + "/v1/organizations/" + org + "/developers";


		var dumpApps = function(email) {
			dev_url = url + "/" + encodeURIComponent(email);
			//Call developer details
			request(dev_url, function (dev_error, dev_response, dev_body) {
				if (!dev_error && dev_response.statusCode == 200) {
					// grunt.verbose.write("Dev body = " + dev_body);
					var dev_detail = JSON.parse(dev_body);
					var last = dev_detail.email;
					var dev_folder = filepath + "/" + dev_detail.email;
					grunt.file.mkdir(dev_folder);
					//Get developer Apps
					var apps_url = url + "/" + encodeURIComponent(dev_detail.email) + "/apps?expand=true";
					grunt.verbose.writeln(apps_url);
					request(apps_url, function (app_error, app_response, app_body) {
						if (!app_error && app_response.statusCode == 200) {

							var apps_detail = JSON.parse(app_body);
							grunt.verbose.writeln(app_body);
							var apps = apps_detail.app;
							//grunt.verbose.writeln(apps);
							if (apps) {
								for (var j = 0; j < apps.length; j++) {
									var app = apps[j];
									key_count += app.credentials.length;
									grunt.verbose.writeln(JSON.stringify(app));
									//var file_name  = dev_folder + "/" + app.appId;
									var file_name = dev_folder + "/" + app.name;
									grunt.verbose.writeln("writing file: " + file_name);
									grunt.file.write(file_name, JSON.stringify(app));
									grunt.verbose.writeln('App ' + app.name + ' written!');
								};
							}
							total_apps += apps.length;

							if (apps.length > 0) {
								grunt.log.ok('Retrieved ' + apps.length + ' apps for ' + dev_detail.email);
								grunt.log.ok('Retrieved ' + key_count + ' keys in total' );
							} else {
								grunt.verbose.writeln('Retrieved ' + apps.length + ' apps for ' + dev_detail.email);
								grunt.log.ok('Retrieved ' + key_count + ' keys in total' );
							}
						}
						else {
							//grunt.verbose.writeln('Error Exporting ' + app.name);
							grunt.verbose.writeln('Error Exporting ' );
							grunt.log.error(body);
						}
						done_count++;
						if (done_count == dev_count) {
							grunt.log.ok('Exported ' + total_apps + ' apps for ' + done_count + ' developers');
							grunt.log.ok('Retrieved ' + key_count + ' keys in total' );
                            grunt.verbose.writeln("================== export Apps DONE()" );
							done();
						}
					}).auth(userid, passwd, true);
				}
				else {
					if (dev_error )
						grunt.log.error(dev_error);
					else
						grunt.log.error(dev_body);
				}
			}).auth(userid, passwd, true);
			// End Developer details
		}

		var iterateOverDevs = function(start, base_url, callback) {
			var url = base_url;

			if (start) {
				url += "?startKey=" + encodeURIComponent(start);
			}
			grunt.verbose.writeln("getting developers..." + url);
			request(url, function (error, response, body) {
				if (!error && response.statusCode == 200) {
					var devs = JSON.parse(body);
					var last = null;

					// detect none and we're done
					if ( devs.length == 0 ) {
						grunt.log.ok('No developers, done');
						done();
					// detect the only developer returned is the one we asked to start with; that's the end game, but wait.
					} else if ( (devs.length == 1) && (devs[0] == start) ) {
						grunt.log.ok('Retrieved TOTAL of ' + dev_count + ' developers, waiting for callbacks to complete');
					} else {
						dev_count += devs.length;
						if (start)
							dev_count--;

						for (var i = 0; i < devs.length; i++) {
							// If there was a 'start', don't do it again, because it was processed in the previous callback.
							if (!start || devs[i] != start) {
								callback(devs[i]);
								last = devs[i];
							}
						}

						grunt.log.ok('Retrieved ' + devs.length + ' developers');

						// Keep on calling getDevs() as long as we're getting new developers back
						iterateOverDevs(last, base_url, callback);
					}
				}
				else {
					if (error)
						grunt.log.error(error);
					else
						grunt.log.error(body);
				}

			}).auth(userid, passwd, true);
		}

		iterateOverDevs(null, url, dumpApps);
		/*
		setTimeout(function() {
		    grunt.verbose.writeln("================== Apps Timeout done" );
		    done(true);
		}, 3000);
		grunt.verbose.writeln("========================= export Apps DONE ===========================" );
		*/
	});



	grunt.registerMultiTask('importApps', 'Import all apps to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
	    var url = apigee.to.url;
	    var org = apigee.to.org;
	    var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var gcp_token = process.env.TOKEN; //modified code
		var auth_header='Bearer ' + gcp_token; //modified code
	    var done_count = 0;
	    var import_count = 0; // added to get the number of apps imported
		var err_count = 0; // added to get the number of apps not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
	    var files;
	    url = url + "/v1/organizations/" + org + "/developers/";
	    var opts = {
	        flatten: false
	    };
	    var f = grunt.option('src');
	    if(f) {
	        grunt.verbose.writeln('src pattern = ' + f);
	        files = grunt.file.expand(opts, f);
	    } else {
	        files = this.filesSrc;
	    }
        var done = this.async();

	    async.eachSeries(files, function(filepath, callback) {
	
	        var folders = filepath.split("/");
	       // var dev = folders[folders.length - 2].toLowerCase();// modified for workaround as fix for Mgnt Api issue
	         var devname = folders[folders.length - 2].toLowerCase();// modified for workaround as fix for Mgnt Api issue
	        //var developer="";
	        var content = grunt.file.read(filepath);
	        var app = JSON.parse(content);
	      //var dev = app.developer;
	      var dev = encodeURIComponent(devname); // modified for workaround as fix for Mgnt Api issue
	     

	        grunt.verbose.writeln("Creating app : " + app.name + " under developer " + dev);

	        var status_done = false;
	        var delete_done = false;
	          //added for app id
			//app.attributes.push({
  			//"name": "Edge-AppID",
  			//"value": app['appId']
			//});

	        delete app['appId'];
	        delete app['developerId'];
	        delete app['lastModifiedAt'];
	        delete app['lastModifiedBy'];
	        delete app['createdAt'];
	        delete app['createdBy'];
	        delete app['appFamily'];
	        delete app['accessType'];
	        delete app['credentials'];
			delete app['developer']; 

	        grunt.verbose.writeln(JSON.stringify(app));
	        var app_url = url + dev + "/apps";
	        grunt.verbose.writeln("Creating App " + app_url);
	       
			
			
			if(app['attributes'] != null)
			{
				var i; //modified code
			   for (i = 0; i < app['attributes'].length; i++) {   //modified code
				app['attributes'][i]['value'] = app['attributes'][i]['value'].toString();
			    }	
		    }
			//modified code
			const options = {
				headers: {'content-type' : 'application/json','Authorization': auth_header}, 
				url:     app_url,
				body:    JSON.stringify(app)  
			  };
			
	        request.post(options, function(error, response, body) {
	                try {
	                    var cstatus = 999;
	                    if(response)
	                        cstatus = response.statusCode;

	                    if(cstatus == 200 || cstatus == 201) {
	                        import_count++;// added to get the number of apps imported
	                        grunt.verbose.writeln('Resp [' + response.statusCode + '] for create app  ' + this.app_url + ' -> ' + body);
	                        var app_resp = JSON.parse(body);
						
	                       	// Set app status
	                        if (app['status'] && (app_resp['status'] != app['status'])) {
						
								var status_url = app_url + '/' + app.name + '?action=';
	                            if(app['status'] == 'approved')
	                                status_url += "approve";
	                            else
	                                status_url += "revoke";

								//grunt.log.writeln("status URL " + status_url); //modified

								//modified code
								const custom_options = {
									headers: {'Authorization':auth_header}, 
									url:     status_url		
								};

	                            request.post(custom_options, function(error, response, body) {
	                                var status = 999;
	                                if(response)
	                                    status = response.statusCode;
	                                grunt.verbose.writeln('Resp [' + status + '] for app status ' + this.dev + ' - ' + this.app_name + ' - ' + this.status_url + ' -> ' + body);
	                                if(error || status != 204)
	                                    grunt.verbose.error('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.status_url + ' -> ' + body);
grunt.log.ok('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.status_url + ' -> ' + body);
	                                // START of fix part1 issue #26
	                                status_done = true;
	                               if(delete_done) {
	                                    done_count++;
	                                    if(done_count == files.length) {
	                                        grunt.log.ok('Processed ' + done_count + ' app(s)');
	                                        grunt.log.ok('Imported ' + import_count + ' app(s)'); // added to get the number of apps imported
	                                        grunt.log.ok('Conflict in ' + 	conflict_count + ' app record(s)'); // added to get the number of 409 records
	                                        error_count =err_count-conflict_count; // added to get the error record count
											grunt.log.ok('Error in ' + 	error_count + ' app record(s)'); // added to get the error record count
	                                        done();
	                                    }
	                                    callback();
	                                }
	                                // END of fix part1 issue #26
	                            }.bind({dev: dev,status_url: status_url,app_name: app.name}));//modified - removed .auth(userid, passwd, true);
	                        }
	                        // START of fix part 2 issue #26
	                        else {
	                            status_done = true;
	                           if(delete_done) {
	                                done_count++;
	                                if(done_count == files.length) {
	                                    grunt.log.ok('Processed ' + done_count + ' app(s)');
	                                    grunt.log.ok('Imported ' + import_count + ' app(s)'); // added to get the number of apps imported
	                                    grunt.log.ok('Conflict in ' + 	conflict_count + ' app record(s)'); // added to get the number of 409 records
	                                    error_count =err_count-conflict_count; // added to get the error record count
										grunt.log.ok('Error in ' + 	error_count + ' app record(s)'); // added to get the error record count
	                                    done();
	                                }
	                                callback();
	                            }
	                        }
	                        // END of fix part 2 issue #26
	                        // END of set App status

	                        // Delete the key generated when App is created
	                        var client_key = app_resp.credentials[0].consumerKey;
	                        var delete_url = app_url + '/' + app.name + '/keys/' + client_key;


							//modified code
							const delete_options = {
								headers: {'Authorization':auth_header},
								url: delete_url
							};
	                       
							request.del(delete_options, function(deleteerror, deletekeyresponse, deletebody) { //modified
	                            var status = 999;
	                            if(deletekeyresponse)
	                                status = deletekeyresponse.statusCode;

	                            grunt.verbose.writeln('Resp [' + status + '] for key delete ' + this.delete_url + ' -> ' + deletebody);
	                            if(deleteerror || status != 200)
	                                grunt.log.error('ERROR Resp [' + status + '] for key delete ' + this.delete_url + ' -> ' + deletebody);

	                            // START of fix part 3 issue #26
	                            delete_done = true;
	                            //grunt.verbose.writeln('delete_done=====3===-----------' + delete_done);
	                            //grunt.verbose.writeln('status_done=====3===-----------' + status_done);
	                                //grunt.verbose.writeln('done_count ======3==-----------' + done_count );

	                            if(status_done) {
	                                done_count++;
	                                if(done_count == files.length) {
	                                    grunt.log.ok('Processed ' + done_count + ' app(s)');
	                                    grunt.log.ok('Imported ' + import_count + ' app(s)'); // added to get the number of apps imported
	                                    grunt.log.ok('Conflict in ' + 	conflict_count + ' app record(s)'); // added to get the number of 409 records
	                                    error_count =err_count-conflict_count; // added to get the error record count
										grunt.log.ok('Error in ' + 	error_count + ' app record(s)'); // added to get the error record count
	                                    done();
	                                }
	                                callback();
	                            }
	                            // END of fix part 3 issue #26					
	                        }.bind({delete_url: delete_url}));//modified - removed .auth(userid, passwd, true);
	                        // END of Key DELETE
	                    } else {
	                        grunt.verbose.writeln('ERROR Resp [' + response.statusCode + '] for create app  ' + this.app_url + ' -> ' + body);
	                         grunt.log.ok('ERROR Resp [' + response.statusCode + '] for create app  ' + this.app_url + ' -> ' + body);
	                        
	                        done_count++;////code changed here-- start
	                        err_count++;
	                        if (response.statusCode==409)// added to get the number of 409 records
			  	            conflict_count++; // added to get the number of 409 records
			  	        	
	                        //grunt.verbose.writeln('done_count ======ERROR-----------==-----------' + done_count );
	                        if(done_count == files.length) {
	                                    grunt.log.ok('Processed ' + done_count + ' app(s)');
	                                    grunt.log.ok('Imported ' + import_count + ' app(s)'); // added to get the number of apps imported
	                                    grunt.log.ok('Conflict in ' + 	conflict_count + ' app record(s)'); // added to get the number of 409 records
	                                    error_count =err_count-conflict_count; // added to get the error record count
										grunt.log.ok('Error in ' + 	error_count + ' app record(s)'); // added to get the error record count
	                                    done();
	                                } ///code changed here -- end 
	                        callback();
	                    }
	                } catch (err) {
	                    grunt.log.error("ERROR - from App URL : " + app_url);
	                    grunt.log.error(body);
	                }
	            }.bind({app_url: app_url}));//modified - removed .auth(userid, passwd, true);
	    });
	});


	grunt.registerMultiTask('deleteApps', 'Delete all apps from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count =0;
		var err_count =0;
		var files;
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		var auth_header='Bearer ' + gcp_token;
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();
		files.forEach(function(filepath) {
			grunt.verbose.writeln("processing file " + filepath);
			var folders = filepath.split("/");
			//var dev = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var devname = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var dev = encodeURIComponent(devname); // modified for workaround as fix for Mgnt Api issue
			var content = grunt.file.read(filepath);
			var app = JSON.parse(content);
			var app_del_url = url + dev + "/apps/" + app.name;
			grunt.verbose.writeln(app_del_url);
			const del_options = {
					headers: {
						   
						   'Authorization': auth_header
					   },
					   url: app_del_url,
					
	 };

			request.del(del_options,function(error, response, body){
			
			   var status = 999;
			   if (response)	
			    status = response.statusCode;
			  grunt.verbose.writeln('Resp [' + status + '] for delete app ' + app_del_url + ' -> ' + body);
			  done_count++;
			  if (error || status!=200){
			  	err_count++;
			  	grunt.verbose.error('ERROR Resp [' + status + '] for delete app ' + app_del_url + ' -> ' + body); 
			  grunt.log.ok('ERROR Resp [' + status + '] for delete app ' + app_del_url + ' -> ' + body); 
			}
			  if (done_count == files.length)
			  {
				grunt.log.ok('Deleted ' + (done_count-err_count) + ' apps');
				done();
			  }
			}.bind( {del_options: del_options}) );	
		});

	});

};


Array.prototype.unique = function() {
    var a = this.concat();
    for(var i=0; i<a.length; ++i) {
        for(var j=i+1; j<a.length; ++j) {
            if(a[i].name === a[j].name)
                a.splice(j--, 1);
        }
    }
    return a;
};
