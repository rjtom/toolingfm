/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var kvms;
module.exports = function(grunt) {
	'use strict';
	grunt.registerTask('exportOrgKVM', 'Export all org-kvm from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
		var url = apigee.from.url;
		var org = apigee.from.org;
		var userid = apigee.from.userid;
		var passwd = apigee.from.passwd;
		var filepath = grunt.config.get("exportOrgKVM.dest.data");
		var done_count = 0;
		var done = this.async();

		grunt.verbose.writeln("========================= export Org KVMs ===========================" );

		url = url + "/v1/organizations/" + org + "/keyvaluemaps";
		grunt.verbose.writeln("getting Org KVMs ..." + url);
		request(url, function (error, response, body) {
			if (!error && response.statusCode == 200) {
				grunt.verbose.writeln("Org KVMs: " + body);
			    kvms =  JSON.parse(body);   
			    
			    if( kvms.length == 0 ) {
                    grunt.verbose.writeln ("exportOrgKVM: No KVMs");
                    grunt.verbose.writeln("================== export ORG KVM DONE()" );
                    done();
                } else {
                	for (var i = 0; i < kvms.length; i++) {
                		// Custom report KVMs have '#'
				    	var org_kvm_url = url + "/" + encodeURIComponent(kvms[i]);
				    	grunt.file.mkdir(filepath);

				    	//Call kvm details
				    	grunt.verbose.writeln('KVM URL: ' + org_kvm_url );
						request(org_kvm_url, function (error, response, body) {
							if (!error && response.statusCode == 200) {
								grunt.verbose.writeln("Org KVM: " + body);
							    var kvm_detail =  JSON.parse(body);
							    var kvm_file = filepath + "/" + kvm_detail.name;
							    grunt.file.write(kvm_file, body);

							    grunt.verbose.writeln('KVM ' + kvm_detail.name + ' written!');
							} else {
								grunt.verbose.writeln('Error ' + response.statusCode + ' exporting ' + error);
								grunt.log.error(error);
							}
							
							done_count++;
							if (done_count == kvms.length)
							{
								grunt.log.ok('Exported ' + done_count + ' kvms');
                                grunt.verbose.writeln("================== export ORG KVM DONE()" );
								done();
							}
						}).auth(userid, passwd, true);
				    	// End kvm details
				    };
			    }
			} 
			else
			{
				grunt.log.error(error);
			}
		}).auth(userid, passwd, true);
		/*
		setTimeout(function() {
		    grunt.verbose.writeln("================== Org KVMs Timeout done" );
		    done(true);
		}, 3000);
		grunt.verbose.writeln("========================= export Org KVMs DONE ===========================" );
		*/
	});



	grunt.registerMultiTask('importOrgKVM', 'Import all Org-kvm to org ' + apigee.to.org  + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var env = apigee.to.env;
		var Fromenv = apigee.from.env;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count =0;
		var mig_count =0;
		var total_count =0;
		var err_count =0;
		var create_count=0;
		var files;
		url = url + "/v1/organizations/" + org + "/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
        var auth_header='Bearer ' + gcp_token;
      
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		

		async.eachSeries(files, function (filepath,callback) {
			var folders = filepath.split("/");
			var input_env = folders[folders.length - 2];
			
		//grunt.log.ok('input_env========'+input_env);
       var kvm = grunt.file.readJSON(filepath);
 //grunt.log.ok(JSON.stringify(kvm));
 var entry = kvm.entry;
 grunt.log.ok('entries list========'+JSON.stringify(entry));
var entry_count=0;


	 async.eachSeries(kvm.entry, function (item, innerCallback) {
      var name = item.name;
  var value = item.value;
  var kvmname = kvm.name;

  // Create a new JSON object with just the name and value properties
  		const newJsonObj = {};
				newJsonObj.name = name;
				newJsonObj.value = value;

				
				var content_str = JSON.stringify(newJsonObj); 
  grunt.log.ok("content_str ==============="+JSON.stringify(content_str));
  var kvm_url = url +"keyvaluemaps/" + kvmname+"/entries";
  grunt.log.ok("Creating kvm entries-----------------" + kvm_url);

   // Make the API call using request.post
  var options = {
        url: kvm_url,
        body: content_str,
        headers: {
          "Authorization": auth_header,
          "Content-Type": "application/json"
        }
      };
           request.post(options, function(error, response, body) {

        if (error) {
          // Handle the error for the specific item
          console.error('Error for item:', item, error);
          innerCallback(error);
        } else {
          // Handle the response or success message
          console.log('API call successful for item:', item);
          mig_count++; // Increment the count of processed entries
          var cstatus = response.statusCode;
          if (cstatus == 200 || cstatus == 201) {
          	entry_count++;
          	create_count++;
            grunt.verbose.writeln('Resp [' + response.statusCode + '] for create org kvm entry ' + this.kvm_url + ' -> ' + body);
          } else {
            grunt.verbose.writeln('ERROR Resp [' + response.statusCode + '] for create org kvm entry  ' + this.kvm_url + ' -> ' + body);
          err_count++;
          }
          	//total_count =done_count+err_count;
          innerCallback();
        }
      }.bind({ kvm_url: kvm_url }));
        }, function(err) {
      if (err) {
        // Handle the error for the kvm entry
        console.error('Error processing kvm entry:', err);
      } else {
        // All API calls for kvm entry completed successfully
        console.log('All API calls for kvm entry completed for org KVM---'+kvm.name+"------- created "+entry_count+" entries------");
        //done_count += kvm.entry.length; // Increment the count of processed entries for this file
        done_count++;
        callback(); // Move to the next iteration (next file)
      }
    });
  }, function() {
    // Task completion callback
    console.log('Total org Kvms entries Processed:', mig_count);
    console.log('Total org Kvms entries Created:', create_count);
    console.log('Total org KVMs Created:', done_count);
    done(); // Task is done
  });
});





////////////--- create Org mapIdentifier -start


grunt.registerMultiTask('createOrgKVMMapId', 'Create Org mapIdentifier-- ' +  apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var env = apigee.to.env;
		var Fromenv = apigee.from.env;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count =0;
		var mig_count =0;
		var err_count=0;
		var files;
		url = url + "/v1/organizations/" + org + "/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
        var auth_header='Bearer ' + gcp_token;
      
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		

		async.eachSeries(files, function (filepath,callback) {
			var folders = filepath.split("/");
				//grunt.log.ok('folders  ---- ' + folders );
			var input_env = folders[folders.length - 2];
				//grunt.log.ok('input_env  ---- ' + input_env );
			var mapId =  folders[folders.length - 1];
			//grunt.log.ok('mapId  ---- ' + mapId );
				var content = grunt.file.read(filepath);
				
			
			
				grunt.log.ok('mapId  ---- ' + mapId );
			
				const newJsonObj = {};
				newJsonObj.name = mapId;
				newJsonObj.encrypted = true;
				
				var content_str = JSON.stringify(newJsonObj); 
  grunt.log.ok(JSON.stringify(content_str));
				//grunt.verbose.writeln("Creating KVM : " + kvm.name + " under env " + env);
				//grunt.verbose.writeln(JSON.stringify(kvm));
				var kvm_url = url + "keyvaluemaps";
				grunt.verbose.writeln("Creating org kvm MapID-----------------" + kvm_url);
			

				request.post({
				  headers: {'Content-Type' : 'application/json','Authorization': auth_header},
				  url:     kvm_url,
				  body:    content_str 
				}, function(error, response, body){
					try{
					  done_count++;
					  
					  var cstatus = 999;
					  if (response)
						cstatus = response.statusCode;
					
					  if (cstatus == 200 || cstatus == 201)
					  {
					  	mig_count++; 
					  grunt.verbose.writeln('Resp [' + response.statusCode + '] for create kvm MapID ' + this.kvm_url + ' -> ' + body);

					  var kvm_resp = JSON.parse(body);
				
					  if (done_count == files.length)
						{
							grunt.log.ok('Created ---- ' + mig_count + ' org kvms MapID');
grunt.log.ok('Error in ---- ' + err_count + ' org kvms MapID creation ');
							done();
						}
						callback();
					  }
					  else
					  {
						err_count++;
						grunt.verbose.writeln('ERROR Resp [' + response.statusCode + '] for create org kvm MapID  ' + this.kvm_url + ' -> ' + body);
						callback();
					  }
					}
					catch(err)
					{
						
						grunt.log.error("ERROR - from org kvm MapID URL : " + kvm_url );
						grunt.log.error(body);
					}

				//}.bind( {kvm_url: kvm_url}) ).auth(userid, passwd, true);
			}.bind( {kvm_url: kvm_url}) );
			//}
		});
		//var done = this.async();
	});


///////////-- Create Org mapIdentifier -- End
	grunt.registerMultiTask('deleteOrgKVM', 'Delete all org-kvm from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
        var auth_header='Bearer ' + gcp_token;
		var done_count = 0;
		var files = this.filesSrc;
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		url = url + "/v1/organizations/" + org + "/keyvaluemaps/";
		var done = this.async();
		files.forEach(function(filepath) {
			var content = grunt.file.read(filepath);
			var kvm = JSON.parse(content);
			var del_url = url + kvm.name;
			grunt.verbose.writeln(del_url);	
			const options = {
			 headers: {
					
					'Authorization': auth_header
				},
				url:     del_url		
		};
			request.del(options, function(error, response, body){
			  var status = 999;
			  if (response)	
				status = response.statusCode;
			  grunt.verbose.writeln('Resp [' + status + '] for kvm deletion ' + this.del_url + ' -> ' + body);
			  if (error || status!=200)
			  { 
			  	grunt.verbose.error('ERROR Resp [' + status + '] for kvm deletion ' + this.del_url + ' -> ' + body); 
			  }
			  done_count++;
			  if (done_count == files.length)
			  {
				grunt.log.ok('Deleted ' + done_count + ' kvms');
				done();
			  }
			}.bind( {del_url: del_url}) );

		});
	});
};
