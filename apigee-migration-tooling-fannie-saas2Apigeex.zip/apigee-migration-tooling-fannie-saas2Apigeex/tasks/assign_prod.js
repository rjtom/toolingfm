/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var apps;
module.exports = function(grunt) {
	'use strict';

	grunt.registerMultiTask('assignProducts', 'assign Products to keys in the org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count =0;
		var assign_count = 0; // added to get the number of products assigned
		var err_count = 0; // added to get the number of keys not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		var prod_assign_total_count=0;
		var files;
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();

		async.eachSeries(files, function(filepath, callback) {
    	var folders = filepath.split("/");
			//var dev = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var devname = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var dev = encodeURIComponent(devname); // modified for workaround as fix for Mgnt Api issue
			var app = grunt.file.readJSON(filepath);

    var credentials = app.credentials;

    //for (var i = 0; i < credentials.length; i++) {
    	 async.eachSeries(credentials, function(item, callback) {
        //var item = credentials[i];
        var cKey = item.consumerKey;
        var cSecret = item.consumerSecret;
        var products = item.apiProducts;
     
        ///////assign prod
        var products_payload = {};

      var prods = [];
      for(let p of products){
        prods.push(p.apiproduct);
      }
   //    Check if the prods array is empty
if (prods.length === 0) {
   prods.push("test-product");
}

      products_payload['apiProducts'] = prods;

      var create_key_url = url + dev + "/apps/" + app.name + "/keys/";

cKey = encodeURI(cKey);
          //grunt.verbose.writeln(create_key_url+ cKey);
         // grunt.verbose.writeln(JSON.stringify(products_payload));
          
        var gcp_token = process.env.TOKEN; //MODIFIED CODE
        var auth_header='Bearer ' + gcp_token;
        
        const options = {
          headers: {
              'Content-Type' : 'application/json',
                 'Authorization': auth_header
            },
             url:  create_key_url + cKey,
               body: JSON.stringify(products_payload)
          
        };


console.log("products_payload -----------------1--------------------"+JSON.stringify(products_payload)+"create_key_url======"+create_key_url + cKey);



        /////////

      
      

      
          request.post(options,function(error, response, body){
            
            var status = 999;
            if (response) 
              status = response.statusCode;
            prod_assign_total_count++;
            grunt.verbose.writeln('Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.products + ' - ' + this.cKey + ' product assignment -> ' + body);
            


           if (error || status!=200){
              
  //console.log("response status  ERROR -----------------2--------------------"+status);
             
              grunt.verbose.error('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.products + ' - ' + this.cKey + ' product assignment -> ' + body); 
              err_count++;
             if ( status==409)
              {
                conflict_count++;
              }
            }  
           
            callback();
        // }.bind( {dev:dev, revoke_key_url: revoke_key_url}) );//MODIFIED CODE - Removed .auth(userid, passwd, true) 

          }.bind( {dev:dev, cKey: cKey, app_name: app.name, products: JSON.stringify(products_payload)}) ); //MODIFIED CODE - Removed .auth(userid, passwd, true)
           
      //}.bind( {developerId : app.developerId, revoke_key_url: revoke_key_url, cKey: cKey, app_name: app.name}))
        }, function(err) {
        if (err) {
            grunt.log.error('ERROR - ' + err);
        } else {
            callback(); // Call the callback function for the parent loop iteration
        }
    });
}, function(err) {
    if (err) {
        grunt.log.error('ERROR - ' + err);
    } else {
        grunt.log.ok(' Total product assignment-' + prod_assign_total_count);
        grunt.log.ok((prod_assign_total_count-err_count) + ' product assignment(s) done successfully');
        grunt.log.ok(err_count + ' product assignment failed');
        grunt.log.ok(conflict_count + ' product assignment failed with 409 conflicts');
    }
    done();
});




});
};


//};
		
	
	