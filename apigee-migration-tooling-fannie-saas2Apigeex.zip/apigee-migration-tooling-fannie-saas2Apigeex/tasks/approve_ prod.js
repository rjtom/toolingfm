/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var apps;
module.exports = function(grunt) {
	'use strict';

	grunt.registerMultiTask('approveProducts', 'approve products in the org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count =0;
		var approve_count = 0; // added to get the number of product approved 
		var err_count = 0; // added to get the number of keys not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		
		var files;
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();

		async.eachSeries(files, function(filepath, callback) {
    	var folders = filepath.split("/");
			//var dev = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var devname = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var dev = encodeURIComponent(devname); // modified for workaround as fix for Mgnt Api issue
			var app = grunt.file.readJSON(filepath);

    var credentials = app.credentials;

    //for (var i = 0; i < credentials.length; i++) {
    	 async.eachSeries(credentials, function(item, callback) {
        //var item = credentials[i];
        var cKey = item.consumerKey;
        var cSecret = item.consumerSecret;
        var credstatus = item.status;
////////
  // Iterate through the apiProducts array
    async.eachSeries(item.apiProducts, function(apiProduct, callback) {
     var ProductName = apiProduct.apiproduct;
      var apiStatus = apiProduct.status;
grunt.log.ok("--ProductName------------------"+ProductName);
grunt.log.ok("--apiStatus-------------------"+apiStatus);



        // Check if the status is "revoked"
        if (apiStatus !== 'approved') {
            // Skip processing 
         return callback();
          //
          //continue ;
        }

        // Process the product
        var create_key_url = url + dev + "/apps/" + app.name + "/keys/";
       var approve_prod_url = create_key_url + cKey + "/apiproducts/" + ProductName + "?action=approve";

grunt.log.ok("--approve_prod_url-------------------"+approve_prod_url);

    
      
            //grunt.log.ok("inside callback main---------------------------------------------------------");
        //MODIFIED CODE - start
        var gcp_token = process.env.TOKEN; //MODIFIED CODE
        var auth_header='Bearer ' + gcp_token;
        
        const options = {
          headers: {
              
              'Authorization': auth_header
            },
            url: approve_prod_url 
          
        };

      
          request.post(options,function(error, response, body){
            
            var status = 999;
            if (response) 
              status = response.statusCode;
                     if (status==204){
            approve_count++;
           }



            grunt.verbose.writeln('Resp [' + status + '] for ' + app.name + ' - ' + this.approve_prod_url+ ' -> ' + body);
            if (error || status!=204){
              err_count++;
              grunt.verbose.error('ERROR Resp [' + status + '] for ' + app.name + ' - ' + this.approve_prod_url+ ' -> ' + body); 
            
              if ( status==409)
              {
                conflict_count++;
              }
            }  
           
            callback();
         }.bind( {dev:dev, approve_prod_url: approve_prod_url}) ); 
 
   }, function(err) {
      if (err) {
        grunt.log.error('ERROR - ' + err);
      } else {
        // Call the callback function for the outer loop iteration
        callback();
      }
    });
  }, function(err) {
    if (err) {
      grunt.log.error('ERROR - ' + err);
    } else {
      // Call the callback function for the parent loop iteration
      callback();
    }
  });
}, function(err) {
  if (err) {
    grunt.log.error('ERROR - ' + err);
  } else {
    grunt.log.ok(approve_count + ' product(s) approved');
    grunt.log.ok(err_count + ' product(s) failed to approve');
    grunt.log.ok(conflict_count + ' product(s) failed with 409 conflicts');
  }
  done();
});




});
};


//};
		
	
	