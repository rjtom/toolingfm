/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var apps;
module.exports = function(grunt) {
	'use strict';

	grunt.registerMultiTask('createDC', 'Create Data Collectors-- ' + "[" + apigee.to.org  + "]", function() {
   
    var filepath = grunt.config.get("createDC.dest.data");
    var url = apigee.to.url;
    var org = apigee.to.org;
    var userid = apigee.to.userid;
    var passwd = apigee.to.passwd;
    var done_count = 0;
    var import_count = 0; // added to get the number of DC imported
    var err_count = 0; // added to get the number of DC not imported
    var conflict_count = 0; // added to get the number of 409 records
    var error_count=0; // added to get the error record count
    var files;
    url = url + "/v1/organizations/" + org + "/datacollectors";
    var done = this.async();
    var opts = {flatten: false};
    var f = grunt.option('src');
    if (f)
    {
      grunt.verbose.writeln('src pattern = ' + f);
      files = grunt.file.expand(opts,f);
    }
    else
    {
      files = this.filesSrc;
    }
    files.forEach(function(filepath) {
      //console.log(filepath);
      var content = grunt.file.read(filepath);
      //grunt.verbose.writeln(url); 
      var DC = JSON.parse(content);
        grunt.verbose.writeln("=========================DCs url==========================="+url );
     grunt.verbose.writeln("========================= DC content ==========================="+JSON.stringify(DC) );




    //MODIFIED CODE - start
    var gcp_token = process.env.TOKEN; //MODIFIED CODE
    
    //var post_url= url; 
    var auth_header='Bearer ' + gcp_token;
    const options = {
       headers: {
          'Content-Type': 'application/json',
          'Authorization': auth_header
        },
        url:     url,
        body:    JSON.stringify(DC)      
    };
      
      //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'
     
      request.post(options,
        function(error, response, body){
      var status = 999;
      if (response) 
       status = response.statusCode;
      grunt.verbose.writeln('Resp [' + status + '] for DC creation ' + this.url + ' -> ' + body);
      if (error || status!=200)
      {
          grunt.verbose.error('ERROR Resp [' + status + '] for DC creation ' + this.url + ' -> ' + JSON.stringify(DC)+body); 
          grunt.log.ok('ERROR Resp [' + status + '] for DC creation ' + this.url + ' -> ' + body); 
          err_count++; // added to get the number of DC not imported
      }
      done_count++;
      if (status==200)// added to get the number of DC imported
          import_count++; // added to get the number of DC imported

      if (status==409)// added to get the number of 409 records
          conflict_count++; // added to get the number of 409 records
      error_count =err_count-conflict_count; // added to get the error record count
      if (done_count == files.length)
      {
        grunt.log.ok('Processed ' + done_count + ' Data Collectors record(s)'); // code changed here
        grunt.log.ok('Imported ' + import_count + ' Data Collectors(s)'); // added to get the number of DC imported
        grunt.log.ok('Conflict in ' +   conflict_count + ' Data Collectors record(s)'); // added to get the number of 409 records
        grunt.log.ok('Error in ' +  error_count + ' Data Collectors record(s)'); // added to get the error record count
        done();
      }

      }.bind( {url: url}) ); //modified - removed .auth(userid, passwd, true);
    });
  });

grunt.registerMultiTask('deleteDC', 'Delete all Data Collectors from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
    var url = apigee.to.url;
    var org = apigee.to.org;
    var userid = apigee.to.userid;
    var passwd = apigee.to.passwd;
    var done_count = 0;
    var error_count = 0;
    var gcp_token = process.env.TOKEN; //MODIFIED CODE
    var auth_header='Bearer ' + gcp_token;
    var files = this.filesSrc;
    var opts = {flatten: false};
    var f = grunt.option('src');
    if (f)
    {
      grunt.verbose.writeln('src pattern = ' + f);
      files = grunt.file.expand(opts,f);
    }
    url = url + "/v1/organizations/" + org + "/datacollectors/";
    var done = this.async();
    files.forEach(function(filepath) {
      var content = grunt.file.read(filepath);
      var DC = JSON.parse(content);

      var del_url = url + DC.name;
      grunt.verbose.writeln(del_url); 


      const dele_options = {
        headers: {
             
             'Authorization': auth_header
           },
           url: del_url,
        
 };
      request.del(dele_options, function(error, response, body){
        var status = 999;
        if (response) 
        status = response.statusCode;
        grunt.verbose.writeln('Resp [' + status + '] for DC deletion ' + this.del_url + ' -> ' + body);
        if (error || status!=200)
        { 
          grunt.verbose.error('ERROR Resp [' + status + '] for DC deletion ' + this.del_url + ' -> ' + body); 
          grunt.log.ok('ERROR Resp [' + status + '] for DC deletion ' + this.del_url + ' -> ' + body); 
          error_count++;
        }
        done_count++;
        if (done_count == files.length)
        {
        grunt.log.ok('Deleted ' + (done_count-error_count) + ' Data Collectors');
        done();
        }
      }.bind( {del_url: del_url}) );

    });
  });


};


//};
		
	
	