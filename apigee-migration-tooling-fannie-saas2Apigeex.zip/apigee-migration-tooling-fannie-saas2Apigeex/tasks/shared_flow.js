/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var shared_flows;
module.exports = function(grunt) {
	'use strict';
	grunt.registerTask('exportSharedFlows', 'Export all shared flows from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
        var url = apigee.from.url;
        var org = apigee.from.org;
        var env = apigee.from.env;
        var userid = apigee.from.userid;
        var passwd = apigee.from.passwd;
        //var oauthToken = process.env.OAUTH; //MODIFIED CODE
        var sfs = apigee.from.sfs;
        var fs = require('fs');
        var filepath = grunt.config.get("exportSharedFlows.dest.data");
        var done_count =0;
        var sf_count =0;
        var done = this.async();
        grunt.log.ok("sfs to export ====="+sfs);
        grunt.verbose.writeln("========================= export Shared Flows ===========================" );
        url = url + "/v1/organizations/" + org + "/sharedflows";
        //grunt.verbose.writeln("Getting shared flows... " + url);
      

        request(url, function (error, response, body) {
            if (!error && response.statusCode == 200) {
                shared_flows =  JSON.parse(body);
                if( shared_flows.length == 0 ) {
                    grunt.verbose.writeln ("exportSharedFlows: No Shared flows");
                    grunt.verbose.writeln("================== export Shared Flows DONE()" );
                    done();
                } else {
                    //for (var i = 0; i < shared_flows.length; i++) {
                           for (var i = 0; i < sfs.length; i++) {
                        var shared_flow_url = url + "/" + sfs[i]+"/deployments";
                        //var sfpath=filepath +"/" +env;
                        var sfpath=filepath ;
                        //grunt.file.mkdir(filepath);
                        grunt.file.mkdir(sfpath);
                        

                        //Call shared flow details
                        request(shared_flow_url, function (error, response, body) {
                            if (!error && response.statusCode == 200) {
                                //grunt.verbose.writeln("SHAREDFLOW " + body);
                                var shared_flow_detail =  JSON.parse(body);
                                var shared_flow_file = filepath + "/" + shared_flow_detail.name;
const environmentName = apigee.from.env;
                                const revisionName = shared_flow_detail.environment.find(env => env.name === environmentName)?.revision[0]?.name;

                                // gets max revision - May not be the deployed version
                                //var max_rev = shared_flow_detail.revision[shared_flow_detail.revision.length -1];
                            
                               var max_rev = revisionName;

                                var shared_flow_download_url = url + "/" + shared_flow_detail.name + "/revisions/" + max_rev + "?format=bundle";
                                grunt.verbose.writeln ("Fetching shared flow bundle ------------- : " + shared_flow_download_url);
                                

                                request(shared_flow_download_url).auth(userid, passwd, true)
                                  .pipe(fs.createWriteStream(sfpath + "/" + shared_flow_detail.name + '.zip'))
                                  .on('close', function () {

                                    grunt.verbose.writeln('Shared Flow---------- ' + shared_flow_detail.name + '.zip written!');
                                    sf_count++;
                                    done_count++;
                                    if (done_count == sfs.length)
                                    {
                                        grunt.log.ok('Exported ' + sf_count + ' shared flows from '+ env );
                                        grunt.verbose.writeln("================== export Shared Flows DONE()" );
                                        done();
                                    }
                                  });
                            }
                            else
                            {
                                done_count++;
                                if (done_count == sfs.length)
                                {
                                    grunt.verbose.writeln('Error exporting ' + sf_count + ' shared flows from '+ env );
                                    grunt.verbose.writeln("================== export Shared Flows error DONE()" );
                                    done();
                                } else {
                                    grunt.verbose.writeln('Error exporting: ' + response.statusCode + " URL: " + shared_flow_url);
                                }
                                grunt.log.error(error);
                            }
                        }).auth(userid, passwd, true);
                        // End shared flow details
                    }; 
                }
            } 
            else
            {
                grunt.verbose.writeln("ERROR getting SharedFlows: " + response.statusCode + " response: " + error);
                grunt.log.error(error);
            }
        }).auth(userid, passwd, true);
        /*
        setTimeout(function() {
            grunt.verbose.writeln("================== Shared Flows Timeout done" );
            done(true);
        }, 3000);
        grunt.verbose.writeln("========================= export Shared Flows DONE ===========================" );
        */
    });

    grunt.registerMultiTask('importSharedFlows', 'Import all shared flows to org ' + 
        apigee.to.org + " [" + apigee.to.version + "]", function() {
        var url = apigee.to.url;
        var org = apigee.to.org;
        var env = apigee.from.env;
        var userid = apigee.to.userid;
        var passwd = apigee.to.passwd;
       
        var files;
        var done_count = 0;
        var sf_count=0;
        url = url + "/v1/organizations/" + org + "/sharedflows?action=import&name=";
        var fs = require('fs');
        var opts = {flatten: false};
        var f = grunt.option('src');
        if (f)
        {
            grunt.verbose.writeln('src pattern = ' + f);
            files = grunt.file.expand(opts,f);
        }
        else
        {
            files = this.filesSrc;
        }

        files.forEach(function(filepath) {
            
            var filename = filepath.replace(/^.*[\\\/]/, '');
            var name = filename.slice(0, -4);
           
           //MODIFIED CODE - start
			var gcp_token = process.env.TOKEN; //MODIFIED CODE
			//var gcp_token = apigee.to.gcp_token;
			
			var post_url= url+name; 
			var auth_header='Bearer ' + gcp_token;
			const options = {
				url: post_url,
				headers: {
				  'Authorization': auth_header
				}
			  };
			grunt.log.ok("post_url====="+post_url);
			  //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'

            //var req = request.post(url+name, function (err, resp, body) {// code modified here
            var req = request.post(options, function (err, resp, body) {
              if (err) {
                grunt.verbose.log(err);
              } else {
                grunt.verbose.writeln('Resp [' + resp.statusCode + '] for shared flow creation ' + name+ ' -> ' + body);
               if (resp.statusCode == '200') sf_count++;
              }
              done_count++;
              if (done_count == files.length)
                {
                    grunt.log.ok('Imported ' + sf_count + ' shared flows');
                    done();
                }
            }.bind( {url: options}) ); //MODIFIED CODE - Removed .auth(userid, passwd, true),use options in post paramters instead of 'url+name'
            var form = req.form();
            form.append('file', fs.createReadStream(filepath));
        });
        var done = this.async();
    });

    grunt.registerMultiTask('deleteSharedFlows', 'Delete all shared flows from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
        var url = apigee.to.url;
        var org = apigee.to.org;
        var userid = apigee.to.userid;
        var passwd = apigee.to.passwd;
        var done_count =0;
        var err_count =0;
        var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
            var auth_header='Bearer ' + gcp_token;
        var files;
        url = url + "/v1/organizations/" + org + "/sharedflows/";
        var done = this.async();
        var opts = {flatten: false};
        var f = grunt.option('src');
        if (f)
        {
            grunt.verbose.writeln('src pattern = ' + f);
            files = grunt.file.expand(opts,f);
        }
        else
        {
            files = this.filesSrc;
        }
        var done = this.async();
        files.forEach(function(filepath) {
            grunt.verbose.writeln("processing file " + filepath);
            var folders = filepath.split("/");
            var shared_flow_file = folders[folders.length - 1];
            var shared_flow = shared_flow_file.split(".")[0];
            var app_del_url = url + shared_flow;
            grunt.verbose.writeln(app_del_url);
            const options = {
                url: app_del_url,
                headers: {
                  'Authorization': auth_header
                }
              };//MODIFIED CODE -end
            request.del(options, function(error, response, body){
              grunt.verbose.writeln('Resp [' + response.statusCode + '] for shared flow deletion ' + this.app_del_url + ' -> ' + body);
              if (error || response.statusCode!=200)
              {
                  grunt.verbose.error('ERROR Resp [' + response.statusCode + '] for shared flow deletion ' + this.app_del_url + ' -> ' + body);
                  err_count++;
                  }
                  done_count++;
                  if (done_count == files.length)
                {
                    grunt.log.ok('Deleted ' + (done_count-err_count) + ' shared flows');
                    done();
                }
          //  }.bind( {app_del_url: app_del_url}) ).auth(userid, passwd, true);
      }.bind( {app_del_url: app_del_url}) );
        });
    });


    grunt.registerTask('deploySharedFlows', 'Deploy revision 1 on all shared flows for org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
            var url = apigee.to.url;
            var org = apigee.to.org;
            var env = apigee.to.env;
            var userid = apigee.to.userid;
            var passwd = apigee.to.passwd;
            var done_count =0;
            var err_count =0;
            var total_count=0
            var done = this.async();
            url = url + "/v1/organizations/" + org ;
			var shared_flows_url = url +  "/sharedflows" ;
           
            //var shared_flow_url;

            var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
            var auth_header='Bearer ' + gcp_token;
            const options1 = {
                url: shared_flows_url,
                headers: {
                  'Authorization': auth_header
                }
              };//MODIFIED CODE -end


            //request(shared_flows_url, function (error, response, body) { //MODIFIED CODE 
            request(options1, function (error, response, body) {
                if (!error && response.statusCode == 200) {
                    //grunt.log.write(body);
                    shared_flows =  JSON.parse(body);
                   
                 
                    

                    for (var i = 0; i < shared_flows.sharedFlows.length; i++) {
                        var shared_flow_url = url + "/environments/" + env + "/sharedflows/" + shared_flows.sharedFlows[i].name + "/revisions/1/deployments";
                       grunt.verbose.writeln(shared_flow_url);
                     
                        //MODIFIED CODE - start
                
                    const options = {
                    url: shared_flow_url,
                    headers: {
                    'Authorization': auth_header
                    }
                    };
              
              //MODIFIED CODE - end 
                        //Call shared flow deploy
                        //request.post(shared_flow_url, function (error, response, body) {//MODIFIED CODE
                        request.post(options, function (error, response, body) {
                            if (!error && response.statusCode == 200) {
                                grunt.verbose.writeln('Resp [' + response.statusCode + '] for shared flow deployment ' + this.shared_flow_url + ' -> ' + body);
                
                              done_count++;
                            }
                            else
                            {
                              err_count++;
                                grunt.log.error('ERROR Resp [' + response.statusCode + '] for shared flow deployment ' + this.shared_flow_url + ' -> ' + body);
                              //  console.log('ERROR Resp [' + response.statusCode + '] for shared flow deployment ' + this.shared_flow_url + ' -> ' + body);
                            }
                         total_count= done_count+err_count;
                              if (total_count == shared_flows.sharedFlows.length)
                            {
                                grunt.log.ok('Processed ' + done_count + ' shared flows');
                                 grunt.log.ok('Unable to deploy  ' + err_count + ' shared flows');
                               
                                done();
                            }
                        });//MODIFIED CODE--- removed-----.auth(userid, passwd, true);
                        // End shared flow deploy
                    };

                }
                else
                {
                    grunt.log.error(error);
                    console.log('error-------------------' + error);
                }
           // }.bind( {shared_flow_url: shared_flow_url}) ); //MODIFIED CODE---  changed shared_flow_url to options;
    });
    });


    grunt.registerTask('undeploySharedFlows', 'UnDeploy revision 1 on all shared flows for org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
            var url = apigee.to.url;
            var org = apigee.to.org;
            var env = apigee.to.env;
            var userid = apigee.to.userid;
            var passwd = apigee.to.passwd;
            var done_count =0;
            var err_count =0;
            var total_count=0
            var done = this.async();
            url = url + "/v1/organizations/" + org ;
            var shared_flows_url = url +  "/sharedflows" ;
           var gcp_token = process.env.TOKEN; //MODIFIED CODE -start
            var auth_header='Bearer ' + gcp_token;
                    const options = {
                    url: shared_flows_url,
                    headers: {
                    'Authorization': auth_header
                    }
                    };
   
            request(options, function (error, response, body) {
  
                if (!error && response.statusCode == 200) {
                    //grunt.log.write(body);
                    shared_flows =  JSON.parse(body);

                    for (var i = 0; i < shared_flows.sharedFlows.length; i++) {
                        var shared_flow_url = url + "/environments/" + env + "/sharedflows/" + shared_flows.sharedFlows[i].name + "/revisions/1/deployments";
                        grunt.verbose.writeln(shared_flow_url);

                    const options1 = {
                    url: shared_flow_url,
                    headers: {
                    'Authorization': auth_header
                    }
                    };
              
                        //Call shared flow undeploy
                        request.del(options1, function (error, response, body) {
                      
                            if (!error && response.statusCode == 200) {
                                grunt.verbose.writeln(body);
                                      done_count++;
                            }
                            else
                            {
                                err_count ++;
                           console.log('ERROR Resp [' + response.statusCode + '] for shared flow Undeployment ' + this.shared_flow_url + ' -> ' + body);

                            }
                      
                            total_count= done_count+err_count;
                              if (total_count == shared_flows.sharedFlows.length)
                            {
                                 grunt.log.ok('Processed ' + done_count + ' shared flows');
                                 grunt.log.ok('Unable to undeploy  ' + err_count + ' shared flows');
                           
                                done();
                            }
                        //}).auth(userid, passwd, true);
                    });
                        // End shared flow undeploy
                    };

                }
                else
                {
                    grunt.log.error(error);
                }
            //}).auth(userid, passwd, true);
        });
    });

};
