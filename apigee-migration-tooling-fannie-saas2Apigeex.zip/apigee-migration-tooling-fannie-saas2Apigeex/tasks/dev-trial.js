/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var devs;
//const request = require('request'); // Make sure you have the 'request' library installed
module.exports = function(grunt) {
    'use strict';

    var request = require('request');
    var apigee = require('../config.js');
    var async = require('async');
    var devs;

    grunt.registerTask('exportDevs', 'Export all developers from org ' + apigee.from.org + " [" + apigee.from.version + "]", function() {
        var url = apigee.from.url;
        var org = apigee.from.org;
        var userid = apigee.from.userid;
        var passwd = apigee.from.passwd;
        var filepath = grunt.config.get("exportDevs.dest.data");
        var batchSize = 1000; // Adjust this batch size as needed

        console.log("========================= export Devs ===========================");

        // Function to export a batch of developers
        function exportBatch(startIndex, callback) {
            var batchUrl = url + "/v1/organizations/" + org + "/developers?startKey=" + startIndex + "&count=" + batchSize;

            request(batchUrl, function (error, response, body) {
                if (error) {
                    console.error('Error retrieving developers: ' + error.message);
                    callback(error);
                } else if (response.statusCode == 200) {
                    var devs = JSON.parse(body);

                    async.eachSeries(devs, function (email, asyncCallback) {
                        dumpDeveloper(email, function (err) {
                            if (err) {
                                asyncCallback(err);
                            } else {
                                asyncCallback();
                            }
                        });
                    }, function (err) {
                        if (err) {
                            return callback(err);
                        }

                        if (devs.length < batchSize) {
                            // No more developers to fetch
                            callback();
                        } else {
                            // Continue fetching the next batch
                            exportBatch(startIndex + batchSize, callback);
                        }
                    });
                } else {
                    console.error('Error retrieving developers. Status Code: ' + response.statusCode);
                    callback('Error retrieving developers');
                }
            }).auth(userid, passwd, true);
        }

        // Function to export a single developer
        function dumpDeveloper(email, callback) {
            var dev_url = url + "/v1/organizations/" + org + "/developers/" + encodeURIComponent(email);
            console.log("getting developer ---- " + dev_url);

            request(dev_url, function (error, response, body) {
                if (error) {
                    console.error('Error retrieving developer: ' + error.message);
                    callback(error);
                } else if (response.statusCode == 200) {
                    console.log(body);
                    var dev_detail = JSON.parse(body);
                    var dev_file = filepath + "/" + dev_detail.email;
                    grunt.file.write(dev_file, body);
                    console.log('Dev ' + dev_detail.email + ' written!');
                    callback();
                } else {
                    console.error('Error retrieving developer. Status Code: ' + response.statusCode);
                    callback('Error retrieving developer');
                }
            }).auth(userid, passwd, true);
        }

        // Start exporting developers
        exportBatch(0, function (err) {
            if (err) {
                console.error('Error exporting developers: ' + err);
            } else {
                console.log('All developers exported successfully.');
            }
            done(err);
        });
    });
};











////import--
grunt.registerMultiTask('importDevs', 'Import all developers to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count = 0;
		var import_count = 0; // added to get the number of dev imported
		var err_count = 0; // added to get the number of dev not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		var files;
		url = url + "/v1/organizations/" + org + "/developers";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		files.forEach(function(filepath) {
			//console.log(filepath);
			var content = grunt.file.read(filepath);
			//grunt.verbose.writeln(url);	
			var dev = JSON.parse(content);
			 var email=dev['email'];
			 //var MemberSince =dev['createdAt'].toString();

const epochTime = dev['createdAt']; // example epoch timestamp
const date = new Date(epochTime); // create a new Date object using the epoch timestamp
const MemberSince = date.toLocaleString(); // convert the Date object to a human-readable string
//grunt.log.ok('MemberSince' + MemberSince); 

			 //  to get the Member-Since
dev.attributes.push({
  			"name": "Edge-Member-Since",
  			"value": MemberSince
			});

			///
			delete dev['organizationName'];
	        delete dev['status'];
	        delete dev['createdAt'];
	        delete dev['lastModifiedAt'];
	        delete dev['lastModifiedBy'];
	        delete dev['createdBy'];
	        delete dev['email'];
	        dev['email']= email.toLowerCase();





		//MODIFIED CODE - start
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		
		//var post_url= url; 
		var auth_header='Bearer ' + gcp_token;
		const options = {
			 headers: {
					'Content-Type': 'application/json',
					'Authorization': auth_header
				},
				url:     url,
				body:    JSON.stringify(dev)			
		};
		  
		  //MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'
		 
		  request.post(options,
			  function(error, response, body){
			var status = 999;
			if (response)	
			 status = response.statusCode;
			grunt.verbose.writeln('Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body);
			if (error || status!=201)
			{
			  	grunt.verbose.error('ERROR Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for dev creation ' + this.url + ' -> ' + body); 
			  	err_count++; // added to get the number of dev not imported
			}
			done_count++;
			if (status==201)// added to get the number of dev imported
			  	import_count++; // added to get the number of dev imported

			if (status==409)// added to get the number of 409 records
			  	conflict_count++; // added to get the number of 409 records
			error_count =err_count-conflict_count; // added to get the error record count
			if (done_count == files.length)
			{
				grunt.log.ok('Processed ' + done_count + ' developer record(s)'); // code changed here
				grunt.log.ok('Imported ' + import_count + ' developer(s)'); // added to get the number of dev imported
				grunt.log.ok('Conflict in ' + 	conflict_count + ' developer record(s)'); // added to get the number of 409 records
				grunt.log.ok('Error in ' + 	error_count + ' developer record(s)'); // added to get the error record count
				done();
			}

			}.bind( {url: url}) ); //modified - removed .auth(userid, passwd, true);
		});
	});
////import--
	

	grunt.registerMultiTask('deleteDevs', 'Delete all developers from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count = 0;
		var error_count = 0;
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		var auth_header='Bearer ' + gcp_token;
		var files = this.filesSrc;
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		files.forEach(function(filepath) {
			var content = grunt.file.read(filepath);
			var dev = JSON.parse(content);
			var del_url = url + dev.email;
			grunt.verbose.writeln(del_url);	


			const dele_options = {
				headers: {
					   
					   'Authorization': auth_header
				   },
				   url: del_url,
				
 };
			request.del(dele_options, function(error, response, body){
			  var status = 999;
			  if (response)	
				status = response.statusCode;
			  grunt.verbose.writeln('Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body);
			  if (error || status!=200)
			  { 
			  	grunt.verbose.error('ERROR Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body); 
			  	grunt.log.ok('ERROR Resp [' + status + '] for dev deletion ' + this.del_url + ' -> ' + body); 
			  	error_count++;
			  }
			  done_count++;
			  if (done_count == files.length)
			  {
				grunt.log.ok('Deleted ' + (done_count-error_count) + ' developers');
				done();
			  }
			}.bind( {del_url: del_url}) );

		});
	});
};
