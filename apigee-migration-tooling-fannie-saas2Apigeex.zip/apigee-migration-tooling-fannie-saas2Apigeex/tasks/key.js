/*jslint node: true */
var request = require('request');
var apigee = require('../config.js');
var async = require('async');
var apps;
module.exports = function(grunt) {
	'use strict';

	grunt.registerMultiTask('importKeys', 'Import all app keys to org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_count =0;
		var import_count = 0; // added to get the number of keys imported
		var err_count = 0; // added to get the number of keys not imported
		var conflict_count = 0; // added to get the number of 409 records
		var error_count=0; // added to get the error record count
		var prod_assign_count=0; // added to get the error in product assignment
		var prod_app_count=0; // added to get the error in product approval
		var prod_assign_total_count=0;
		var files;
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();

		async.eachSeries(files, function(filepath, callback_files) {
			var folders = filepath.split("/");
			//var dev = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var devname = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var dev = encodeURIComponent(devname); // modified for workaround as fix for Mgnt Api issue
			var app = grunt.file.readJSON(filepath);
//	        var app1 = JSON.parse(app);

			var credentials = app.credentials;
	        //var dev = app.developer;

/*	        var content = grunt.file.read(filepath);
	        var app = JSON.parse(content);
	        var dev = app.developer;*/



			async.eachSeries(credentials, function(item, callback2) {
			 var cKey = item.consumerKey;
		     var cSecret = item.consumerSecret;
			 var products = item.apiProducts;
				
			 if(!cSecret){
                cSecret = "NOSECRETPROVIDED" ;
			 }
			 

			const key_payload = 
			{
			  "consumerKey": cKey,
			  "consumerSecret": cSecret     
			};
			var products_payload = {};

			var prods = [];
			for(let p of products){
				prods.push(p.apiproduct);
			}
			// Check if the prods array is empty
if (prods.length === 0) {
    prods.push("test-product");
}

			products_payload['apiProducts'] = prods;

			var create_key_url = url + dev + "/apps/" + app.name + "/keys/";

		
			async.series([
				function (callback2){
					
				//MODIFIED CODE - start
				var gcp_token = process.env.TOKEN; //MODIFIED CODE
				var auth_header='Bearer ' + gcp_token;
				var key_payloadjson = JSON.stringify(key_payload);

				const options = {
					headers: {
							'Content-Type' : 'application/json',
							'Authorization': auth_header
						},
						url: create_key_url + "create",
						body: key_payloadjson
					
				};

				//console.log("TOKEN FROM ENV VARIABLE: " + process.env.TOKEN);
				//MODIFIED CODE - end - also in next line, use options in post paramters instead of 'url+name'

					request.post(options,
						function(error, response, body){
					  var status = 999;
					  if (response)	
						  status = response.statusCode;
                     
					  //console.log("response status -----------------1--------------------"+status);
					  /// code added to get the number of keys created
					  if (status==200 || status==201){
					  import_count++;
					 }



					  grunt.verbose.writeln('Resp [' + status + '] for ' + this.dev + ' - ' + this.create_key_url + ' -> ' + body);
					  if (error || status!=201){
						  //console.log("response status  ERROR -----------------1--------------------"+status);
						  err_count++;
						  grunt.verbose.error('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.create_key_url + ' -> ' + body); 
						  grunt.log.ok('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.create_key_url + ' -> ' + body); 
						  if ( status==409)
						  {
						  	conflict_count++;
						  }
					  }  
					  callback2(null, 'one');
					}.bind( {dev:dev, create_key_url: create_key_url}) );//MODIFIED CODE - Removed .auth(userid, passwd, true)	
				},

							 // Commenting out product assignment
   
				function(callback2){
					//urlencode the key
					cKey = encodeURI(cKey);
					grunt.verbose.writeln(create_key_url+ cKey);
					grunt.verbose.writeln(JSON.stringify(products_payload));
					
					var gcp_token2 = process.env.TOKEN; //MODIFIED CODE
					var cust_auth_header='Bearer ' + gcp_token2; //MODIFIED CODE

					const cus_options = {
						headers: {
							   'Content-Type' : 'application/json',
							   'Authorization': cust_auth_header
						   },
						   url:  create_key_url + cKey,
						   body: JSON.stringify(products_payload)
						};

//console.log("products_payload -----------------1--------------------"+JSON.stringify(products_payload)+"create_key_url======"+create_key_url);
					 request.post(cus_options,
					function(error, response, body){
					  var status = 999;
					  if (response)	
						  status = response.statusCode;
					prod_assign_total_count++;
					 //console.log("response status----------------2-----------------------"+status);

					  grunt.verbose.writeln('Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.products + ' - ' + this.cKey + ' product assignment -> ' + body);
					  if (error || status!=200){
					  	//console.log("response status  ERROR -----------------2--------------------"+status);
					  	prod_assign_count++;
					  	grunt.log.ok('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.products + ' - ' + this.cKey + ' product assignment -> ' + body); 
					  	grunt.verbose.error('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.products + ' - ' + this.cKey + ' product assignment -> ' + body); 
					  }
					 callback2(null, 'two');
					}.bind( {dev:dev, cKey: cKey, app_name: app.name, products: JSON.stringify(products_payload)}) );	//MODIFIED CODE - Removed .auth(userid, passwd, true)
					
				},


				 // Commenting out product approval code
    /*
				function(callback2){
					var done_cnt =0;

					for(let p of prods){
						var approve_key_url = create_key_url + cKey + "/apiproducts/" + p + "?action=approve";
						grunt.verbose.writeln("Approve products for key ----- " + approve_key_url);
					
						var approve_auth_header='Bearer ' + process.env.TOKEN;//MODIFIED CODE
						const approve_options = {    //MODIFIED CODE
							headers: {
								   'Authorization': approve_auth_header
							   },
							   url:  approve_key_url
							};

						request.post(approve_options, function(error, response, body){
							var status = 999;
							if (response)	
								status = response.statusCode;
							
							//console.log("response status --------------------3--------------------"+status);
	
							grunt.verbose.writeln('Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.product + ' - ' + this.cKey + ' - ' + this.approve_key_url + ' -> ' + body);
							if (error || status!=204)
								{
									//console.log("response status  ERROR -----------------3--------------------"+status);
									prod_app_count++;
									grunt.log.ok('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.product + ' - ' + this.cKey + ' - ' + this.approve_key_url + ' -> ' + body); 
									grunt.verbose.error('ERROR Resp [' + status + '] for ' + this.dev + ' - ' + this.app_name + ' - ' + this.product + ' - ' + this.cKey + ' - ' + this.approve_key_url + ' -> ' + body); 
								}
							done_cnt++;							 
							if (done_cnt == prods.length)
								  callback2(null, 'three');
							}.bind( {dev:dev, approve_key_url: approve_key_url, cKey: cKey, app_name: app.name, product: p}))
					}
				}*/
			], function(err, results){
				grunt.verbose.writeln("Keys migrated for app ------------" + app.name );
				done_count++;
				error_count =err_count-conflict_count; 
					//grunt.verbose.writeln("done count ------------" + done_count );
						//grunt.verbose.writeln("error count ------------" +error_count );
							//grunt.verbose.writeln("files length ------------" + files.length);
								//grunt.verbose.writeln("imported keys  ------------" + import_count );
							
				if (done_count == files.length) {
					grunt.log.ok('Processed ' + done_count + ' app record(s) to import keys ');
					grunt.log.ok('Imported ' + import_count + ' key(s)');
					grunt.log.ok('Conflict in  ' + conflict_count + ' keys record(s)');
					grunt.log.ok('Error in ' + error_count + ' keys record(s)');
					grunt.log.ok('Error in ' + prod_assign_count + ' product assignment record(s)');
					grunt.log.ok('Total ' + prod_assign_total_count + ' product assignment record(s)');
					grunt.log.ok('Error in ' + prod_app_count + ' product approval record(s)');
					done();
				}
			});
			  return callback2();
			}, function() {
			  return callback_files();
			})
		  })

		},function() {
			console.log('done');
		  });
		

		
	
	grunt.registerMultiTask('deleteKeys', 'Delete all app keys from org ' + apigee.to.org + " [" + apigee.to.version + "]", function() {
	
		var url = apigee.to.url;
		var org = apigee.to.org;
		var userid = apigee.to.userid;
		var passwd = apigee.to.passwd;
		var done_flag =false;
		var file_count = 0;
		var err_count = 0;
		var done_count = 0;
		var key_count = 0;
		var files;
		var gcp_token = process.env.TOKEN; //MODIFIED CODE
		var auth_header='Bearer ' + gcp_token;
		url = url + "/v1/organizations/" + org + "/developers/";
		var done = this.async();
		var opts = {flatten: false};
		var f = grunt.option('src');
		if (f)
		{
			grunt.verbose.writeln('src pattern = ' + f);
			files = grunt.file.expand(opts,f);
		}
		else
		{
			files = this.filesSrc;
		}
		var done = this.async();

		files.forEach(function(filepath) {
			var folders = filepath.split("/");

			//var dev = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var devname = folders[folders.length - 2].toLowerCase(); // modified for workaround as fix for Mgnt Api issue
			var dev = encodeURIComponent(devname); // modified for workaround as fix for Mgnt Api issue
			var app = grunt.file.readJSON(filepath);
			var credentials = app.credentials;

			for (var i = 0; i < credentials.length; i++) {
				key_count++;

				var cKey = credentials[i].consumerKey;
				//urlencode the key
				cKey = encodeURI(cKey);
				var delete_key_url = url + dev + "/apps/" + app.name + "/keys/" + cKey;
				grunt.verbose.writeln(delete_key_url);  
				
				const del_options = {
					headers: {
						   
						   'Authorization': auth_header
					   },
					   url: delete_key_url,
					
	 };

				request.del(del_options, function(error, response, body){
				  var status = 999;
				  if (response)	
				  	status = response.statusCode;
				  done_count++;
				  grunt.verbose.writeln('Resp [' + status + '] for ' + this.cKey + ' deletion -> ' + body);
				  if (error || status!=200){
				  	err_count++;
				  	grunt.verbose.error('ERROR Resp [' + status + '] for ' + this.cKey + ' deletion -> ' + body); 
				  grunt.log.ok('ERROR Resp [' + status + '] for ' + this.cKey + ' deletion -> ' + body); 
				}
				  if (i == credentials.length)
				  	file_count++;
				    //console.log("done_count -----------------2--------------------"+done_count);
				    // console.log("err_count -----------------2--------------------"+err_count);
				     //  console.log("key_count -----------------2--------------------"+key_count);
				     //     console.log("file_count -----------------2--------------------"+file_count);
				       //      console.log("files.length -----------------2--------------------"+files.length);
				             			//  if ((file_count == files.length) && (i == credentials.length))
				  if ((file_count == key_count) && (done_count== key_count))
				  {
				  	grunt.log.ok('Deleted ' + (done_count-err_count) + ' Keys');
				  	done();
				  }
				}.bind( {cKey: cKey}) );	
			//};
		
			};
		});
	});

};