module.exports = {
    from: {
                version: '1',
                url: 'https://api.enterprise.apigee.com',
                userid: '**@digitaldisruptionllc.com',
                passwd: '**',
                org: '',
                env: '',
                revIndex: '0',
                apis:[],
                sfs:[]
    },
    to: {
        version: '1',
        url: 'https://apigee.googleapis.com',
        userid: 'admin@**.com',
        passwd: '*****',
        org: '',
        env: ''
    }};
